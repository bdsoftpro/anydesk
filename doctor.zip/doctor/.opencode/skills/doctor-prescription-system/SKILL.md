---
name: doctor-prescription-system
description: >
  Build and maintain a Flutter Android Doctor Prescription System using Pure Dart,
  encrypted SQLite (sqlite3/sqlite3mc), a hybrid clinical decision-support engine,
  and a phase-wise medical database. Use when planning, implementing, reviewing,
  or extending this project's architecture, database, clinical workflows, safety,
  prescriptions, synchronization, or documentation.
---

# Doctor Prescription System — OpenCode Skill

## Purpose

এই Skill ব্যবহার করে Doctor Prescription System-এর architecture, Flutter/Dart implementation,
SQLite database, clinical knowledge base, hybrid decision-support engine, prescription workflow
এবং development roadmap তৈরি ও রক্ষণাবেক্ষণ করতে হবে।

## Project context

- Platform: Android-first Flutter application.
- Frontend and application logic: Flutter + Dart / Pure Dart.
- Backend direction: Pure Dart with `dart:io`.
- Database: `sqlite3: ^3.5.1` with sqlite3mc / Multi-Cipher encryption.
- Search: SQLite FTS5.
- Clinical engine: deterministic Rule Engine + AI/RAG, coordinated by a Clinical Decision Orchestrator.
- Initial user: doctor. Future scope: multiple doctors, clinics, hospitals, remote server, multi-device sync and optional AI services.
- Explanations and project documentation should be in Bengali. Keep code, identifiers, SQL names, package names and API names in English.

## Mandatory working rules

1. **Follow the ten-phase roadmap.** Implement one phase at a time. Do not silently skip dependencies or mix unrelated phases.
2. **Inspect before changing.** When working in an existing repository, inspect its structure, conventions, migrations, dependencies and current implementation before creating or modifying files.
3. **Preserve existing project decisions.** Do not replace the chosen Flutter + Pure Dart + SQLite/sqlite3mc architecture with an unrelated framework or database without explaining the trade-off and obtaining approval.
4. **Database-first consistency.** Every new clinical workflow must have corresponding schema, constraints, indexes, migrations, repositories and tests where applicable.
5. **Use migrations, not destructive resets.** Never use `DROP TABLE` or destructive recreation in production migration paths. Preserve existing patient and clinical records.
6. **Use transactions for related writes.** Enable foreign keys, keep transactions short, and serialize database writes through a controlled write path.
7. **Protect medical data.** Use encrypted database/storage, least-privilege access, audit logs, secure backups and explicit consent where applicable. Never expose patient-identifying data to an external AI service; de-identify/minimize it first.
8. **Keep AI optional.** The application’s essential patient, clinical-rule and prescription workflows must remain usable when the AI service is unavailable.
9. **Never turn AI output into a clinical action automatically.** AI suggestions must remain proposals until a doctor reviews and approves them.
10. **Do not invent clinical facts.** Missing patient data, test results, references or guideline details must be marked as missing/unknown. AI must never fabricate laboratory results or silently infer a confirmed diagnosis.
11. **Show uncertainty and evidence.** Possible diagnoses must be represented as differentials, with supporting evidence, missing information, source references and engine/knowledge-base versions.
12. **Clinical content requires qualified review.** Do not author or approve real-world diagnosis rules, medication doses, contraindications or treatment recommendations as clinically validated. Mark unverified sample content clearly and require review by qualified clinicians and applicable Bangladesh authorities before deployment.
13. **Maintain explainability and auditability.** Record the assessment input snapshot, rule-engine version, AI model identifier (if used), knowledge-base version, source references, timestamp and doctor decision.
14. **Test safety-critical paths.** Include tests for missing data, conflicting Rule/AI results, emergency alerts, allergies, medication interactions, authorization, audit logging, migrations and offline operation.
15. **Deliver complete, usable changes.** When asked to implement a phase, provide the actual files/code, migration order, indexes/constraints, tests and concise Bengali implementation notes. Do not return only a conceptual outline unless asked.

## Architecture boundaries

Keep these responsibilities separate:

- **Presentation:** Flutter screens and widgets.
- **Application / Domain:** patient, clinical, prescription services and validation.
- **Rule Engine:** structured clinical criteria and safety rules.
- **AI Engine:** language interpretation, retrieval and explanations; not a source of final clinical authority.
- **Clinical Decision Orchestrator:** reconcile Rule Engine and AI outputs, surface conflicts/missing data, run safety validation and request doctor review.
- **Data Access:** repositories, transaction manager, cache and sync queue.
- **Persistence:** encrypted SQLite database, medical knowledge base and patient records.
- **Remote services:** optional AI API, encrypted backup, medical-content updates and multi-device synchronization.

Do not allow UI widgets to execute SQL directly. Route persistence through repositories/services and a single controlled database access layer.

## Phase-wise implementation order

1. **Core Foundation & Doctor Management:** users, doctors, qualifications, specialties, sessions, roles, permissions, app settings, audit logs and schema migrations.
2. **Patient Management & Medical History:** patient profile, contacts, addresses, emergency contacts, allergies, conditions, surgeries, family history, current medications and consents.
3. **Symptoms & Clinical Observation:** symptom master, Bangla/English synonyms, follow-up questions, patient encounters, encounter symptoms, vital signs and observation methods.
4. **Disease & Clinical Knowledge Base:** disease master/categories/synonyms, disease-symptom mapping, risk factors, differentials, complications, clinical rules, rule conditions/actions/versions and clinical sources.
5. **Physical Examination & Lab Investigation:** examination categories/types/findings, encounter examinations, lab test master/categories, disease-test mapping, orders, order items, results, result values and reference ranges.
6. **Medicine Reference & Treatment Guidelines:** medicine categories, generics, brands, manufacturers, dosage forms, strengths, routes, packages, safety rules, interactions, treatment guidelines and guideline versions.
7. **Clinical Decision Support Engine:** assessments, inputs, differentials, evidence, missing data, alerts, investigations, guidelines, AI runs, source references, engine versions and doctor review decisions.
8. **Prescription Management:** prescriptions, doctor-approved diagnoses, medicine items, instructions, investigations, notes, versions, signatures and templates.
9. **Follow-up, Reports & Patient Monitoring:** schedules, follow-up records, progress notes, outcomes, reports, print logs, medical documents and attachments.
10. **Sync, Security & Administration:** devices, device sessions, sync queue/logs, backup history, encryption-key metadata, data-access logs, content-update logs, knowledge-base versions and notifications.

Respect dependencies between phases. For example, encounter-linked symptoms depend on patients and encounters; clinical assessments depend on the clinical data and knowledge base; prescriptions depend on doctor review.

## Clinical workflow invariants

- Every doctor visit is a separate `patient_encounters` record.
- Keep patient-reported symptoms separate from clinician-observed findings.
- Keep physical examination, lab orders and actual lab results as distinct records.
- A lab result may only come from a recorded result source; never generate it from AI.
- A disease and its symptoms form a many-to-many relationship through `disease_symptoms`.
- Medicine reference data is not a prescription.
- AI-proposed medicines must not be inserted as final `prescription_items` until a doctor reviews and approves them.
- Prescription status workflow: `DRAFT` → `UNDER_REVIEW` → `APPROVED` → `SIGNED`; cancellation must be explicit and audited.
- When Rule Engine and AI results disagree, expose the conflict; do not automatically choose one as confirmed.
- Emergency indicators must be prominent and must not be suppressed by AI confidence or ranking.

## SQLite implementation standards

- Enable `PRAGMA foreign_keys = ON` for every connection.
- Use UTC ISO-8601 timestamps consistently.
- Store booleans as integer `0` / `1`.
- Use foreign keys, `NOT NULL`, `UNIQUE`, `CHECK` constraints and indexes wherever appropriate.
- Use versioned, forward-only migrations. Include migration tests and preserve existing data.
- Use FTS5 for searchable Bangla/English symptom, disease and medicine reference text where suitable.
- Route writes through a serialized write queue or equivalent controlled mechanism.
- Keep transactions short; avoid long-running write transactions.
- Validate WAL compatibility with the selected sqlite3mc encryption configuration before enabling it.
- Use SQLite Backup API or an equivalent consistent backup mechanism; do not copy a live database file as an ordinary file.
- Store attachments using an appropriately protected file-storage strategy; database encryption alone does not automatically encrypt external files.
- Do not log passwords, encryption keys, access tokens or unnecessary patient-identifying data.

## Suggested Flutter project structure

Use the following as the baseline, adapting to the repository’s established conventions:

```text
lib/
  app/
    app.dart
    router.dart
    app_config.dart
  core/
    database/
      database.dart
      migrations/
      transaction_manager.dart
    security/
    network/
    sync/
    search/
    pdf/
    utils/
  features/
    authentication/
    dashboard/
    doctors/
    patients/
    medical_history/
    symptoms/
    clinical_analysis/
    diseases/
    physical_examination/
    lab_investigations/
    treatment_guidelines/
    medicine_reference/
    prescriptions/
    follow_up/
    reports/
  clinical_engine/
    rule_engine/
    ai_engine/
    knowledge_base/
    safety_engine/
    orchestrator/
    explainability/
  shared/
    widgets/
    models/
    services/
    design_tokens/
```

## Expected implementation response

For each requested task:

1. Identify the target phase and dependencies.
2. Briefly state assumptions and any missing requirements.
3. Inspect existing code before editing, if a repository is available.
4. Implement using existing conventions and the architecture above.
5. Include schema/migration, constraints, indexes and repository/service changes when relevant.
6. Add tests, especially for clinical safety and data integrity.
7. Summarize changed files, migration/run steps and remaining clinician-review requirements in Bengali.

---

## Source architecture reference

The following section preserves the supplied project architecture and phase-wise database specification. Treat it as the project’s baseline reference; apply the mandatory safety and implementation rules above when turning it into working code.

একটি Android (Flutter + Dart) বেস অ্যাপ হিসেবে চালু করা যায় এবং ভবিষ্যতে একাধিক ডাক্তার, ক্লিনিক, হাসপাতাল, অনলাইন সার্ভার ও AI মডিউল যুক্ত করা যায়।

# ১. Project Architecture

# Doctor Prescription System

High-level system architecture

Flutter Android Application

Dashboard · Patients · Symptoms · Diagnosis · Tests · Prescription

Application / Domain Layer

Patient Service · Clinical Service · Prescription Service · Validation

Rule Engine

Clinical Rules · Decision Tables · Safety Rules

AI Engine

Symptom Interpretation · Knowledge Retrieval · Explanation

Clinical Decision Orchestrator

Rule Results + AI Results + Safety Validation + Doctor Review

Data Access Layer

Repository · Transaction Manager · Cache · Sync Queue

SQLite3 + sqlite3mc

Encrypted Clinical Database · Medical Knowledge Base · Patient Records

Optional Remote Services

AI API · Encrypted Backup · Medical Content Updates · Multi-device Sync

## ২. Technology Stack

| Layer               | Technology                                  |
| ------------------- | ------------------------------------------- |
| Frontend            | Flutter + Dart                              |
| State Management    | Flutter-native / Riverpod (প্রয়োজন অনুযায়ী) |
| Application Logic   | Pure Dart                                   |
| Backend             | Pure Dart + `dart:io`                       |
| Database            | `sqlite3: ^3.5.1`                           |
| Database Encryption | sqlite3mc / Multi-Cipher                    |
| Search              | SQLite FTS5                                 |
| Rule Engine         | Custom Dart Clinical Rule Engine            |
| AI                  | LLM + RAG                                   |
| PDF                 | Prescription PDF Generator                  |
| Background Tasks    | Dart Isolates                               |
| Data Sync           | REST API + Sync Queue                       |

গুরুত্বপূর্ণ: রোগীর তথ্য স্থানীয়ভাবে সংরক্ষিত থাকলেও AI API-তে পাঠানোর আগে পরিচয় শনাক্তকারী তথ্য বাদ দিতে হবে। AI API ব্যবহার না করেও Rule Engine-এর মাধ্যমে অ্যাপের মূল কাজ চালু রাখতে হবে।

# ৩. Application Modules

প্রস্তাবিত Flutter project structure:

```
lib/
├── app/
│   ├── app.dart
│   ├── router.dart
│   └── app_config.dart
│
├── core/
│   ├── database/
│   │   ├── database.dart
│   │   ├── migrations/
│   │   └── transaction_manager.dart
│   ├── security/
│   ├── network/
│   ├── sync/
│   ├── search/
│   ├── pdf/
│   └── utils/
│
├── features/
│   ├── authentication/
│   ├── dashboard/
│   ├── doctors/
│   ├── patients/
│   ├── medical_history/
│   ├── symptoms/
│   ├── clinical_analysis/
│   ├── diseases/
│   ├── physical_examination/
│   ├── lab_investigations/
│   ├── treatment_guidelines/
│   ├── medicine_reference/
│   ├── prescriptions/
│   ├── follow_up/
│   └── reports/
│
├── clinical_engine/
│   ├── rule_engine/
│   ├── ai_engine/
│   ├── knowledge_base/
│   ├── safety_engine/
│   ├── orchestrator/
│   └── explainability/
│
└── shared/
    ├── widgets/
    ├── models/
    ├── services/
    └── design_tokens/
```

# ৪. Phase-wise Database Design

আমি Database-কে ১০টি Phase-এ ভাগ করছি। এতে প্রতিটি Phase আলাদাভাবে তৈরি ও পরীক্ষা করা যাবে।

## Phase-1: Core Foundation & Doctor Management

Foundation

উদ্দেশ্য: অ্যাপের মূল ভিত্তি, ডাক্তার, লগইন, সেটিংস ও নিরাপত্তা।

| Table                   | কাজ                     |
| ----------------------- | ----------------------- |
| `doctors`               | ডাক্তারদের তথ্য         |
| `doctor_qualifications` | ডিগ্রি ও যোগ্যতা        |
| `doctor_specialties`    | বিশেষজ্ঞতার Master      |
| `doctor_sessions`       | লগইন সেশন               |
| `users`                 | ব্যবহারকারী             |
| `user_roles`            | Role Master             |
| `permissions`           | Permission Master       |
| `role_permissions`      | Role-Permission Mapping |
| `app_settings`          | অ্যাপ সেটিংস            |
| `audit_logs`            | পরিবর্তনের ইতিহাস       |
| `schema_migrations`     | Database Version        |

প্রাথমিক Doctor Table:

```
CREATE TABLE doctors (
    id              INTEGER PRIMARY KEY,
    doctor_code     TEXT NOT NULL UNIQUE,
    full_name       TEXT NOT NULL,
    registration_no TEXT,
    phone           TEXT,
    email           TEXT,
    qualification   TEXT,
    specialty_id    INTEGER,
    is_active       INTEGER NOT NULL DEFAULT 1,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);
```

## Phase-2: Patient Management & Medical History

উদ্দেশ্য: রোগীর সম্পূর্ণ Medical Profile তৈরি।

| Table                        | কাজ                    |
| ---------------------------- | ---------------------- |
| `patients`                   | রোগীর Master           |
| `patient_contacts`           | যোগাযোগের তথ্য         |
| `patient_addresses`          | ঠিকানা                 |
| `patient_emergency_contacts` | জরুরি যোগাযোগ          |
| `patient_allergies`          | অ্যালার্জি             |
| `patient_conditions`         | পূর্বের রোগ            |
| `patient_surgeries`          | অপারেশনের ইতিহাস       |
| `patient_family_history`     | পারিবারিক রোগের ইতিহাস |
| `patient_medications`        | বর্তমানে ব্যবহৃত ওষুধ  |
| `patient_consents`           | তথ্য ব্যবহারের সম্মতি  |

গুরুত্বপূর্ণ Patient Fields:

```
id
patient_code
full_name
date_of_birth
sex
blood_group
phone
emergency_contact
created_at
updated_at
```

বয়স সরাসরি সংরক্ষণ না করে `date_of_birth` থেকে হিসাব করা ভালো।

## Phase-3: Symptoms & Clinical Observation

Core Clinical Module

উদ্দেশ্য: রোগীর লক্ষণ ও পর্যবেক্ষণযোগ্য তথ্য সংরক্ষণ।

| Table                      | কাজ                                |
| -------------------------- | ---------------------------------- |
| `symptom_categories`       | লক্ষণের Category                   |
| `symptoms`                 | Symptom Master                     |
| `symptom_synonyms`         | বাংলা ও ইংরেজি সমার্থক শব্দ        |
| `symptom_questions`        | Follow-up Questions                |
| `symptom_question_options` | প্রশ্নের উত্তর                     |
| `patient_encounters`       | প্রতিটি Doctor Visit               |
| `encounter_symptoms`       | Visit অনুযায়ী লক্ষণ                |
| `clinical_observations`    | Vital Signs                        |
| `observation_types`        | Temperature, Pulse ইত্যাদির Master |
| `observation_methods`      | মাপার পদ্ধতি                       |

উদাহরণ:

| Symptom    | বাংলা      | English    |
| ---------- | ---------- | ---------- |
| Fever      | জ্বর       | Fever      |
| Headache   | মাথাব্যথা  | Headache   |
| Cough      | কাশি       | Cough      |
| Vomiting   | বমি        | Vomiting   |
| Chest Pain | বুকে ব্যথা | Chest Pain |
| Fatigue    | ক্লান্তি   | Fatigue    |

প্রতিটি Symptom-এর সঙ্গে থাকবে:

- Onset (কখন শুরু)
- Duration (কতদিন)
- Severity (তীব্রতা)
- Frequency (কতবার)
- Location (কোথায়)
- Progression (বাড়ছে না কমছে)
- Associated Symptoms

এখানে শুধু রোগীর বলা তথ্য এবং ডাক্তার পর্যবেক্ষণ করেছেন এমন তথ্য আলাদাভাবে সংরক্ষণ করতে হবে।

## Phase-4: Disease & Clinical Knowledge Base

Knowledge Base

উদ্দেশ্য: রোগের Master এবং রোগ-লক্ষণ সম্পর্ক তৈরি।

| Table                      | কাজ                        |
| -------------------------- | -------------------------- |
| `disease_categories`       | রোগের Category             |
| `diseases`                 | Disease Master             |
| `disease_synonyms`         | রোগের বিকল্প নাম           |
| `disease_symptoms`         | রোগ ও লক্ষণের সম্পর্ক      |
| `disease_risk_factors`     | Risk Factors               |
| `disease_differentials`    | Differential Diagnosis     |
| `disease_complications`    | জটিলতার তথ্য               |
| `clinical_rules`           | Clinical Rule Master       |
| `clinical_rule_conditions` | Rule Conditions            |
| `clinical_rule_actions`    | Rule Actions               |
| `clinical_rule_versions`   | Rule Version History       |
| `clinical_sources`         | Clinical Reference Sources |

এখানে একটি গুরুত্বপূর্ণ বিষয়:

একটি রোগের সঙ্গে অনেক লক্ষণ এবং একটি লক্ষণের সঙ্গে অনেক রোগের সম্পর্ক থাকবে। তাই `disease_symptoms` হবে Many-to-Many Junction Table।

```
diseases
   │
   ├──── disease_symptoms
   │          │
   │          └──── symptoms
   │
   ├──── disease_risk_factors
   │
   └──── disease_differentials
```

## Phase-5: Physical Examination & Lab Investigation

উদ্দেশ্য: ডাক্তার কর্তৃক শারীরিক পরীক্ষা এবং Laboratory Investigation পরিচালনা।

| Table                    | কাজ                         |
| ------------------------ | --------------------------- |
| `examination_categories` | Examination Category        |
| `examination_types`      | Physical Examination Master |
| `examination_findings`   | Examination Findings        |
| `encounter_examinations` | Visit অনুযায়ী পরীক্ষা       |
| `lab_test_categories`    | Lab Test Category           |
| `lab_tests`              | Lab Test Master             |
| `disease_lab_tests`      | রোগ ও Lab Test Mapping      |
| `lab_orders`             | Test Orders                 |
| `lab_order_items`        | Order Details               |
| `lab_results`            | Test Results                |
| `lab_result_values`      | Individual Result Values    |
| `lab_reference_ranges`   | Reference Ranges            |

এখানে তিনটি বিষয় আলাদা থাকবে:

1. Physical Examination: ডাক্তার সরাসরি পরীক্ষা করে যা দেখেছেন।
2. Lab Investigation: কোন পরীক্ষা বিবেচনা বা অর্ডার করা হয়েছে।
3. Lab Result: পরীক্ষার প্রকৃত ফলাফল।

AI কখনো পরীক্ষার ফলাফল তৈরি বা অনুমান করে Database-এ লিখতে পারবে না।

## Phase-6: Medicine Reference & Treatment Guidelines

উদ্দেশ্য: ওষুধের Reference Information এবং চিকিৎসা নির্দেশিকা সংরক্ষণ।

| Table                          | কাজ                       |
| ------------------------------ | ------------------------- |
| `medicine_categories`          | Medicine Category         |
| `medicine_generics`            | Generic Master            |
| `medicine_brands`              | Brand Master              |
| `medicine_manufacturers`       | Manufacturer              |
| `medicine_dosage_forms`        | Dosage Form               |
| `medicine_strengths`           | Strength Reference        |
| `medicine_routes`              | Route Reference           |
| `medicine_packages`            | Packaging                 |
| `medicine_safety_rules`        | Safety Information        |
| `medicine_interactions`        | Interaction Reference     |
| `treatment_guidelines`         | Treatment Guidelines      |
| `disease_treatment_guidelines` | Disease-Guideline Mapping |
| `guideline_versions`           | Guideline Version History |

বিশেষ নিয়ম: এই মডিউলের Medicine Reference Data এবং Prescription-এর মধ্যে পার্থক্য থাকবে। Reference Data কোনো স্বয়ংক্রিয় প্রেসক্রিপশন নয়। নির্দিষ্ট রোগের জন্য ওষুধ নির্বাচন, ডোজ ও ব্যবহারের সময়কাল চিকিৎসকের যাচাই ছাড়া তৈরি বা অনুমোদন করা যাবে না।

## Phase-7: Clinical Decision Support Engine

Hybrid Engine

এটি আপনার অ্যাপের সবচেয়ে গুরুত্বপূর্ণ অংশ।

| Table                       | কাজ                       |
| --------------------------- | ------------------------- |
| `clinical_assessments`      | Clinical Analysis Session |
| `assessment_inputs`         | Analysis Input            |
| `assessment_differentials`  | সম্ভাব্য রোগের তালিকা     |
| `assessment_evidence`       | কোন তথ্যের ভিত্তিতে ফলাফল |
| `assessment_missing_data`   | অনুপস্থিত তথ্য            |
| `assessment_alerts`         | Safety Alerts             |
| `assessment_investigations` | বিবেচিত পরীক্ষা           |
| `assessment_guidelines`     | প্রাসঙ্গিক Guideline      |
| `ai_analysis_runs`          | AI Analysis History       |
| `ai_source_references`      | AI ব্যবহৃত Source         |
| `clinical_engine_versions`  | Engine Version            |
| `clinical_review_decisions` | Doctor Review             |

### Hybrid Engine-এর কাজ

Patient Clinical Data

Rule Engine

Structured Rules, Clinical Criteria, Safety Checks

AI Engine

Natural Language, Context, Knowledge Retrieval

Result Reconciliation

Conflicts · Missing Data · Evidence · Safety Validation

Doctor Review & Decision

AI Engine-এর দায়িত্ব:

- বাংলা ও ইংরেজি ভাষায় লেখা লক্ষণ বুঝতে সহায়তা করা।
- অস্পষ্ট লক্ষণ শনাক্ত করে Follow-up Question প্রস্তাব করা।
- Rule Engine-এর ফলাফল সহজ ভাষায় ব্যাখ্যা করা।
- অনুমোদিত Medical Knowledge Base থেকে তথ্য খুঁজে দেওয়া।
- অনুপস্থিত Clinical Information চিহ্নিত করা।

Rule Engine-এর দায়িত্ব:

- নির্ধারিত Clinical Criteria পরীক্ষা করা।
- বিপজ্জনক লক্ষণ ও Safety Alert যাচাই করা।
- প্রাসঙ্গিক Investigation ও Guideline দেখানো।
- AI-এর ভুল বা unsupported সিদ্ধান্তের বিরুদ্ধে Validation করা।

দুই Engine-এর ফলাফল না মিললে সিস্টেম নিজে কোনো একটি ফলাফলকে নিশ্চিত বলে বেছে নেবে না।

## Phase-8: Prescription Management

উদ্দেশ্য: ডাক্তার কর্তৃক প্রেসক্রিপশন তৈরি ও সংরক্ষণ।

| Table                         | কাজ                        |
| ----------------------------- | -------------------------- |
| `prescriptions`               | Prescription Master        |
| `prescription_diagnoses`      | ডাক্তার অনুমোদিত Diagnosis |
| `prescription_items`          | Medicine Items             |
| `prescription_instructions`   | রোগীকে নির্দেশনা           |
| `prescription_investigations` | পরীক্ষার নির্দেশ           |
| `prescription_notes`          | Doctor Notes               |
| `prescription_versions`       | পরিবর্তনের ইতিহাস          |
| `prescription_signatures`     | অনুমোদন ও স্বাক্ষর         |
| `prescription_templates`      | Doctor Templates           |

Prescription Status:

```
DRAFT
UNDER_REVIEW
APPROVED
SIGNED
CANCELLED
```

এখানে AI-এর তৈরি কোনো প্রস্তাব সরাসরি `prescription_items`-এ যাবে না। ডাক্তার যাচাই ও অনুমোদন করার পরেই Prescription চূড়ান্ত হবে।

## Phase-9: Follow-up, Reports & Patient Monitoring

| Table                     | কাজ                     |
| ------------------------- | ----------------------- |
| `follow_up_schedules`     | Follow-up Schedule      |
| `follow_up_records`       | Follow-up Visit         |
| `patient_progress_notes`  | অগ্রগতির নোট            |
| `clinical_outcomes`       | Outcome Tracking        |
| `doctor_reports`          | Doctor Reports          |
| `prescription_print_logs` | Print History           |
| `patient_document_files`  | Medical Documents       |
| `patient_attachments`     | Image / PDF Attachments |

## Phase-10: Sync, Security & Administration

| Table                     | কাজ                     |
| ------------------------- | ----------------------- |
| `devices`                 | Device Management       |
| `device_sessions`         | Device Session          |
| `sync_queue`              | Pending Sync            |
| `sync_logs`               | Sync History            |
| `backup_history`          | Backup Records          |
| `encryption_key_versions` | Key Version Metadata    |
| `data_access_logs`        | Sensitive Data Access   |
| `content_update_logs`     | Medical Content Updates |
| `knowledge_base_versions` | Knowledge Base Versions |
| `system_notifications`    | System Alerts           |

# ৫. গুরুত্বপূর্ণ Database Relationships

নিচের Mermaid Diagram-এ মূল Clinical Data Relationship দেখানো হলো।

\#chatgpt-mermaid-\_r_nf\_{font-family:-apple-system-body,ui-sans-serif,-apple-system,system-ui,"Segoe UI",Helvetica,"Apple Color Emoji",Arial,sans-serif,"Segoe UI Emoji","Segoe UI Symbol";font-size:16px;fill:rgb(13, 13, 13);}@keyframes edge-animation-frame{from{stroke-dashoffset:0;}}@keyframes dash{to{stroke-dashoffset:0;}}#chatgpt-mermaid-\_r_nf\_ .edge-animation-slow{stroke-dasharray:9,5!important;stroke-dashoffset:900;animation:dash 50s linear infinite;stroke-linecap:round;}#chatgpt-mermaid-\_r_nf\_ .edge-animation-fast{stroke-dasharray:9,5!important;stroke-dashoffset:900;animation:dash 20s linear infinite;stroke-linecap:round;}#chatgpt-mermaid-\_r_nf\_ .error-icon{fill:rgb(243, 243, 243);}#chatgpt-mermaid-\_r_nf\_ .error-text{fill:rgb(13, 13, 13);stroke:rgb(13, 13, 13);}#chatgpt-mermaid-\_r_nf\_ .edge-thickness-normal{stroke-width:1px;}#chatgpt-mermaid-\_r_nf\_ .edge-thickness-thick{stroke-width:3.5px;}#chatgpt-mermaid-\_r_nf\_ .edge-pattern-solid{stroke-dasharray:0;}#chatgpt-mermaid-\_r_nf\_ .edge-thickness-invisible{stroke-width:0;fill:none;}#chatgpt-mermaid-\_r_nf\_ .edge-pattern-dashed{stroke-dasharray:3;}#chatgpt-mermaid-\_r_nf\_ .edge-pattern-dotted{stroke-dasharray:2;}#chatgpt-mermaid-\_r_nf\_ .marker{fill:rgb(143, 143, 143);stroke:rgb(143, 143, 143);}#chatgpt-mermaid-\_r_nf\_ .marker.cross{stroke:rgb(143, 143, 143);}#chatgpt-mermaid-\_r_nf\_ svg{font-family:-apple-system-body,ui-sans-serif,-apple-system,system-ui,"Segoe UI",Helvetica,"Apple Color Emoji",Arial,sans-serif,"Segoe UI Emoji","Segoe UI Symbol";font-size:16px;}#chatgpt-mermaid-\_r_nf\_ p{margin:0;}#chatgpt-mermaid-\_r_nf\_ .entityBox{fill:rgb(222, 234, 251);stroke:rgb(83, 154, 248);}#chatgpt-mermaid-\_r_nf\_ .relationshipLabelBox{fill:rgb(243, 243, 243);opacity:0.7;background-color:rgb(243, 243, 243);}#chatgpt-mermaid-\_r_nf\_ .relationshipLabelBox rect{opacity:0.5;}#chatgpt-mermaid-\_r_nf\_ .labelBkg{background-color:rgba(243, 243, 243, 0.5);}#chatgpt-mermaid-\_r_nf\_ .edgeLabel{background-color:rgb(252, 252, 252);}#chatgpt-mermaid-\_r_nf\_ .edgeLabel .label rect{fill:rgb(252, 252, 252);}#chatgpt-mermaid-\_r_nf\_ .edgeLabel .label text{fill:rgb(13, 13, 13);}#chatgpt-mermaid-\_r_nf\_ .edgeLabel .label{fill:rgb(83, 154, 248);font-size:14px;}#chatgpt-mermaid-\_r_nf\_ .label{font-family:-apple-system-body,ui-sans-serif,-apple-system,system-ui,"Segoe UI",Helvetica,"Apple Color Emoji",Arial,sans-serif,"Segoe UI Emoji","Segoe UI Symbol";color:rgb(13, 13, 13);}#chatgpt-mermaid-\_r_nf\_ .edge-pattern-dashed{stroke-dasharray:8,8;}#chatgpt-mermaid-\_r_nf\_ .node rect,#chatgpt-mermaid-\_r_nf\_ .node circle,#chatgpt-mermaid-\_r_nf\_ .node ellipse,#chatgpt-mermaid-\_r_nf\_ .node polygon{fill:rgb(222, 234, 251);stroke:rgb(83, 154, 248);stroke-width:1px;}#chatgpt-mermaid-\_r_nf\_ .relationshipLine{stroke:rgb(143, 143, 143);stroke-width:1px;fill:none;}#chatgpt-mermaid-\_r_nf\_ .marker{fill:none!important;stroke:rgb(143, 143, 143)!important;stroke-width:1;}#chatgpt-mermaid-\_r_nf\_ [data-look=neo].labelBkg{background-color:rgba(243, 243, 243, 0.5);}#chatgpt-mermaid-\_r_nf\_ .node .neo-node{stroke:rgb(83, 154, 248);}#chatgpt-mermaid-\_r_nf\_ [data-look="neo"].node rect,#chatgpt-mermaid-\_r_nf\_ [data-look="neo"].cluster rect,#chatgpt-mermaid-\_r_nf\_ [data-look="neo"].node polygon{stroke:url(#chatgpt-mermaid-\_r_nf\_-gradient);filter:drop-shadow( 1px 2px 2px rgba(185,185,185,1));}#chatgpt-mermaid-\_r_nf\_ [data-look="neo"].swimlane.cluster rect{filter:none;}#chatgpt-mermaid-\_r_nf\_ [data-look="neo"].node path{stroke:url(#chatgpt-mermaid-\_r_nf\_-gradient);stroke-width:1px;}#chatgpt-mermaid-\_r_nf\_ [data-look="neo"].node .outer-path{filter:drop-shadow( 1px 2px 2px rgba(185,185,185,1));}#chatgpt-mermaid-\_r_nf\_ [data-look="neo"].node .neo-line path{stroke:rgb(83, 154, 248);filter:none;}#chatgpt-mermaid-\_r_nf\_ [data-look="neo"].node circle{stroke:url(#chatgpt-mermaid-\_r_nf\_-gradient);filter:drop-shadow( 1px 2px 2px rgba(185,185,185,1));}#chatgpt-mermaid-\_r_nf\_ [data-look="neo"].node circle .state-start{fill:#000000;}#chatgpt-mermaid-\_r_nf\_ [data-look="neo"].icon-shape .icon{fill:url(#chatgpt-mermaid-\_r_nf\_-gradient);filter:drop-shadow( 1px 2px 2px rgba(185,185,185,1));}#chatgpt-mermaid-\_r_nf\_ [data-look="neo"].icon-shape .icon-neo path{stroke:url(#chatgpt-mermaid-\_r_nf\_-gradient);filter:drop-shadow( 1px 2px 2px rgba(185,185,185,1));}#chatgpt-mermaid-\_r_nf\_ :root{--mermaid-font-family:-apple-system-body,ui-sans-serif,-apple-system,system-ui,"Segoe UI",Helvetica,"Apple Color Emoji",Arial,sans-serif,"Segoe UI Emoji","Segoe UI Symbol";}DOCTORSPATIENT_ENCOUNTERSPATIENTSENCOUNTER_SYMPTOMSSYMPTOMSCLINICAL_OBSERVATIONSENCOUNTER_EXAMINATIONSDISEASESDISEASE_SYMPTOMSCLINICAL_ASSESSMENTSASSESSMENT_DIFFERENTIALSASSESSMENT_INVESTIGATIONSLAB_TESTSPRESCRIPTIONSPRESCRIPTION_ITEMSMEDICINE_BRANDSPRESCRIPTION_VERSIONSDOCTOR_REVIEWSmanagesvisitscontainsidentifiesrecordsincludesmapsmapsanalyzesproducessuggestssuggestsreferencesgeneratescontainsreferencesversionsreviews

# ৬. Clinical Engine-এর Data Flow

প্রতিটি Doctor Visit-কে একটি আলাদা `patient_encounters` Record হিসেবে রাখতে হবে।

উদাহরণ:

```
Patient
   |
   └── Encounter
          |
          ├── Symptoms
          ├── Medical History
          ├── Allergies
          ├── Vital Signs
          ├── Physical Examination
          |
          └── Clinical Assessment
                 |
                 ├── Rule Engine Results
                 ├── AI Analysis Results
                 ├── Possible Diagnoses
                 ├── Suggested Investigations
                 ├── Safety Alerts
                 |
                 └── Doctor Review
                        |
                        └── Prescription
```

প্রতিটি Assessment-এর সঙ্গে নিচের তথ্য সংরক্ষণ করতে হবে:

- Analysis Input Snapshot
- Rule Engine Version
- AI Model Identifier
- Knowledge Base Version
- Clinical Sources
- Result Timestamp
- Doctor Decision
- Review Timestamp

এতে পরে বোঝা যাবে কোন তথ্য ও কোন Engine Version ব্যবহার করে কোনো ফলাফল তৈরি হয়েছিল।

# ৭. SQLite Database Design Rules

আপনার SQLite3/sqlite3mc প্রকল্পে কয়েকটি নিয়ম বাধ্যতামূলক রাখার পরামর্শ দিচ্ছি।

| বিষয়              | প্রস্তাব                    |
| ----------------- | --------------------------- |
| Primary Key       | `INTEGER` অথবা UUID/ULID    |
| Foreign Key       | সব সম্পর্কযুক্ত টেবিলে      |
| DateTime          | UTC ISO-8601                |
| Boolean           | `INTEGER` 0/1               |
| Medical Records   | Soft Delete + Audit         |
| Database Writes   | Transaction                 |
| Concurrent Writes | Serialized Write Queue      |
| Search            | FTS5                        |
| Encryption        | sqlite3mc                   |
| Schema Updates    | Versioned Migrations        |
| Backups           | Encrypted Consistent Backup |
| Attachments       | Encrypted File Storage      |

বিশেষ করে:

- `PRAGMA foreign_keys = ON` চালু রাখতে হবে।
- Database write operation এক জায়গা থেকে নিয়ন্ত্রণ করতে হবে।
- দীর্ঘস্থায়ী transaction এড়িয়ে চলতে হবে।
- WAL mode ব্যবহার করলে backup ও encryption configuration-এর সঙ্গে সামঞ্জস্য পরীক্ষা করতে হবে।
- SQLite database file-কে সাধারণ file-copy দিয়ে চলমান অবস্থায় backup না করে SQLite Backup API বা সমতুল্য নিরাপদ পদ্ধতি ব্যবহার করতে হবে।
- Audit Log থেকে গুরুত্বপূর্ণ Medical Record পরিবর্তনের ইতিহাস মুছে ফেলা যাবে না।

# ৮. Clinical Safety & Quality Architecture

এটি সাধারণ ERP বা POS-এর মতো অ্যাপ নয়। এখানে ভুল Clinical Output রোগীর ক্ষতি করতে পারে। তাই কিছু বিষয় Architecture-এর মধ্যেই রাখতে হবে।

| Safety Control  | নিয়ম                                 |
| --------------- | ------------------------------------ |
| Diagnosis       | সম্ভাব্য রোগ, নিশ্চিত রোগ নয়         |
| Emergency       | জরুরি লক্ষণ হলে স্পষ্ট সতর্কতা       |
| AI Output       | Doctor Approval ছাড়া কার্যকর নয়      |
| Medication      | Contraindication ও interaction যাচাই |
| Lab Tests       | Clinical rationale সংরক্ষণ           |
| Missing Data    | অনুমান না করে তথ্য চাইতে হবে         |
| Guideline       | Source ও version বাধ্যতামূলক         |
| Prescription    | Doctor-reviewed ও authenticated      |
| Audit           | প্রতিটি গুরুত্বপূর্ণ সিদ্ধান্ত লগ    |
| Content Updates | চিকিৎসক-পর্যালোচিত ও versioned       |

অ্যাপের Clinical Content তৈরি ও যাচাইয়ে যোগ্য চিকিৎসক, সংশ্লিষ্ট বিশেষজ্ঞ এবং প্রযোজ্য স্থানীয় চিকিৎসা নির্দেশিকা ব্যবহার করতে হবে। বাংলাদেশে প্রকাশ বা বাস্তব ব্যবহারের আগে প্রযোজ্য DGDA, BMDC, তথ্য সুরক্ষা ও অন্যান্য নিয়ন্ত্রক শর্ত যাচাই করা প্রয়োজন।

# ৯. Development Roadmap

প্রতিটি Phase-এর কাজ আলাদা করে সম্পন্ন করার প্রস্তাব দিচ্ছি।

| Phase | Development Target       | Priority |
| ----- | ------------------------ | -------- |
| 1     | Core Foundation & Doctor | সর্বোচ্চ |
| 2     | Patient Management       | সর্বোচ্চ |
| 3     | Symptoms & Observation   | সর্বোচ্চ |
| 4     | Disease Knowledge Base   | উচ্চ     |
| 5     | Examination & Lab        | উচ্চ     |
| 6     | Medicine Reference       | উচ্চ     |
| 7     | Hybrid Clinical Engine   | সর্বোচ্চ |
| 8     | Prescription Builder     | সর্বোচ্চ |
| 9     | Follow-up & Reports      | মাঝারি   |
| 10    | Sync & Security          | উচ্চ     |
