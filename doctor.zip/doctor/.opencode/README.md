# OpenCode Skill

Copy the project skill into:

`.opencode/skills/doctor-prescription-system/SKILL.md`

The skill is packaged separately in the companion ZIP generated with this project.
