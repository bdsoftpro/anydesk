import 'dart:convert';
import 'dart:math';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorageService {
  static const _databaseKeyName = 'doctor_prescription_database_key';
  static const _sessionTokenName = 'doctor_prescription_session_token';

  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  Future<String> getOrCreateDatabaseKey() async {
    final existing = await _storage.read(key: _databaseKeyName);
    if (existing != null && existing.length >= 64) return existing;

    final random = Random.secure();
    final bytes = List<int>.generate(32, (_) => random.nextInt(256));
    final key = base64UrlEncode(bytes);
    await _storage.write(key: _databaseKeyName, value: key);
    return key;
  }

  Future<void> saveSessionToken(String token) =>
      _storage.write(key: _sessionTokenName, value: token);

  Future<String?> readSessionToken() =>
      _storage.read(key: _sessionTokenName);

  Future<void> clearSessionToken() =>
      _storage.delete(key: _sessionTokenName);
}
