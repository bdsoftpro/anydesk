import 'database_service.dart';

class AppSettingsRepository {
  AppSettingsRepository(this.database);
  final DatabaseService database;

  String? get(String key) {
    final rows = database.db.select(
      'SELECT setting_value FROM app_settings WHERE setting_key = ?',
      [key],
    );
    return rows.isEmpty ? null : rows.first['setting_value'] as String;
  }

  void set(String key, String value) {
    database.db.execute(
      '''INSERT INTO app_settings(setting_key, setting_value, updated_at)
         VALUES (?, ?, ?)
         ON CONFLICT(setting_key) DO UPDATE SET
           setting_value = excluded.setting_value,
           updated_at = excluded.updated_at''',
      [key, value, DateTime.now().toUtc().toIso8601String()],
    );
  }
}
