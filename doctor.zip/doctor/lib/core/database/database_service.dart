import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqlite3/sqlite3.dart';

import '../security/secure_storage_service.dart';

class DatabaseService {
  DatabaseService({required this.secureStorage});

  final SecureStorageService secureStorage;
  Database? _database;

  Database get db {
    final value = _database;
    if (value == null) {
      throw StateError('DatabaseService.initialize() was not called.');
    }
    return value;
  }

  Future<DatabaseService> initialize() async {
    if (_database != null) return this;

    final directory = await getApplicationSupportDirectory();
    final databasePath = p.join(directory.path, 'doctor_prescription.db');
    final key = await secureStorage.getOrCreateDatabaseKey();

    final database = sqlite3.open(databasePath);

    // IMPORTANT: PRAGMA key must be the first database statement.
    // Key material is generated per installation and held in Android secure storage.
    final escapedKey = key.replaceAll("'", "''");
    database.execute("PRAGMA key = '$escapedKey';");

    // Force a read so an incorrect key / non-encrypted existing file fails early.
    database.select('SELECT count(*) FROM sqlite_master');
    database.execute('PRAGMA foreign_keys = ON;');
    database.execute('PRAGMA busy_timeout = 5000;');

    _database = database;
    await _runMigrations(database);
    return this;
  }

  Future<void> _runMigrations(Database database) async {
    database.execute('''
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        applied_at TEXT NOT NULL
      );
    ''');

    const migrations = <(int, String)>[
      (1, '001_core.sql'),
      (2, '002_patients.sql'),
      (3, '003_clinical.sql'),
      (4, '004_knowledge.sql'),
      (5, '005_investigations.sql'),
      (6, '006_medicines.sql'),
      (7, '007_assessments.sql'),
      (8, '008_prescriptions.sql'),
      (9, '009_followup.sql'),
      (10, '010_sync_security.sql'),
      (11, '011_phase1_auth_hardening.sql'),
    ];

    for (final migration in migrations) {
      final version = migration.$1;
      final name = migration.$2;
      final exists = database.select(
        'SELECT version FROM schema_migrations WHERE version = ?',
        [version],
      );
      if (exists.isNotEmpty) continue;

      final sql = await rootBundle.loadString(
        'assets/database/migrations/$name',
      );

      database.execute('BEGIN IMMEDIATE;');
      try {
        database.execute(sql);
        database.execute(
          'INSERT INTO schema_migrations(version, name, applied_at) VALUES (?, ?, ?)',
          [version, name, DateTime.now().toUtc().toIso8601String()],
        );
        database.execute('COMMIT;');
      } catch (_) {
        database.execute('ROLLBACK;');
        rethrow;
      }
    }
  }

  void close() {
    _database?.dispose();
    _database = null;
  }
}
