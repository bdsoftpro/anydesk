import '../clinical_assessment.dart';

abstract interface class AiEngine {
  Future<ClinicalAssessmentProposal?> analyze(
    Map<String, Object?> deidentifiedEncounterSnapshot,
  );
}

/// AI is optional. A null result means the provider is unavailable or disabled.
class DisabledAiEngine implements AiEngine {
  @override
  Future<ClinicalAssessmentProposal?> analyze(
    Map<String, Object?> deidentifiedEncounterSnapshot,
  ) async => null;
}
