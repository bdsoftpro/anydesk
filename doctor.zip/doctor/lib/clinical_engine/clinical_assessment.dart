class ClinicalEvidence {
  const ClinicalEvidence({
    required this.code,
    required this.description,
    required this.source,
  });

  final String code;
  final String description;
  final String source;
}

class ClinicalAssessmentProposal {
  const ClinicalAssessmentProposal({
    required this.possibleConditions,
    required this.missingInformation,
    required this.alerts,
    required this.evidence,
    required this.requiresDoctorReview,
  });

  final List<String> possibleConditions;
  final List<String> missingInformation;
  final List<String> alerts;
  final List<ClinicalEvidence> evidence;
  final bool requiresDoctorReview;
}
