import '../ai_engine/ai_engine.dart';
import '../clinical_assessment.dart';
import '../rule_engine/rule_engine.dart';

class ClinicalOrchestrator {
  ClinicalOrchestrator({
    required this.ruleEngine,
    required this.aiEngine,
  });

  final RuleEngine ruleEngine;
  final AiEngine aiEngine;

  Future<ClinicalAssessmentProposal> assess(
    Map<String, Object?> encounterSnapshot,
  ) async {
    final ruleResult = await ruleEngine.evaluate(encounterSnapshot);

    // The caller must provide a minimized/de-identified snapshot.
    // This scaffold intentionally does not send data to any network service.
    final aiResult = await aiEngine.analyze(encounterSnapshot);

    if (aiResult == null) return ruleResult;

    final conflicts = <String>[];
    if (ruleResult.possibleConditions.toSet()
        .difference(aiResult.possibleConditions.toSet()).isNotEmpty ||
        aiResult.possibleConditions.toSet()
        .difference(ruleResult.possibleConditions.toSet()).isNotEmpty) {
      conflicts.add('Rule Engine ও AI ফলাফলে অমিল আছে');
    }

    return ClinicalAssessmentProposal(
      possibleConditions: ruleResult.possibleConditions,
      missingInformation: {
        ...ruleResult.missingInformation,
        ...aiResult.missingInformation,
      }.toList(),
      alerts: {...ruleResult.alerts, ...aiResult.alerts, ...conflicts}.toList(),
      evidence: [...ruleResult.evidence, ...aiResult.evidence],
      requiresDoctorReview: true,
    );
  }
}
