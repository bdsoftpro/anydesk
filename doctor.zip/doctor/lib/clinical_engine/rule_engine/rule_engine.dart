import '../clinical_assessment.dart';

abstract interface class RuleEngine {
  Future<ClinicalAssessmentProposal> evaluate(
    Map<String, Object?> encounterSnapshot,
  );
}

/// Safe default: no unreviewed clinical rules are shipped with this project.
/// Replace with clinician-authored, versioned and tested rule packs.
class EmptyRuleEngine implements RuleEngine {
  @override
  Future<ClinicalAssessmentProposal> evaluate(
    Map<String, Object?> encounterSnapshot,
  ) async {
    return const ClinicalAssessmentProposal(
      possibleConditions: [],
      missingInformation: ['ক্লিনিক্যাল নিয়ম/তথ্য প্যাক এখনো সংযুক্ত নয়'],
      alerts: [],
      evidence: [],
      requiresDoctorReview: true,
    );
  }
}
