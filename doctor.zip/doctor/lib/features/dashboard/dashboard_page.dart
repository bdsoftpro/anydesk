import 'package:flutter/material.dart';

import '../../core/database/database_service.dart';
import '../authentication/auth_models.dart';
import '../doctors/doctor_profile_page.dart';
import '../patients/patient_list_page.dart';
import '../symptoms/symptom_search_page.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({
    super.key,
    required this.database,
    required this.session,
    required this.onLogout,
  });

  final DatabaseService database;
  final AuthSession session;
  final Future<void> Function() onLogout;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ডাক্তার পোর্টাল',
            style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(
            tooltip: 'ডাক্তার প্রোফাইল',
            icon: const Icon(Icons.account_circle_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => DoctorProfilePage(
                  database: database,
                  session: session,
                ),
              ),
            ),
          ),
          IconButton(
            tooltip: 'লগআউট',
            icon: const Icon(Icons.logout),
            onPressed: onLogout,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF303030),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('স্বাগতম',
                    style: TextStyle(color: Colors.white70, fontSize: 14)),
                const SizedBox(height: 8),
                Text(session.doctorName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    )),
                const SizedBox(height: 4),
                Text('@${session.username} • ${session.roles.join(', ')}',
                    style: const TextStyle(color: Colors.white70)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text('প্রধান মডিউল',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          _ModuleTile(
            icon: Icons.people_alt_outlined,
            title: 'রোগী ব্যবস্থাপনা',
            subtitle: 'রোগী যোগ, তালিকা ও প্রোফাইল',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => PatientListPage(database: database),
              ),
            ),
          ),
          _ModuleTile(
            icon: Icons.manage_search,
            title: 'লক্ষণ অনুসন্ধান',
            subtitle: 'বাংলা ও ইংরেজি লক্ষণ খুঁজুন',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SymptomSearchPage(database: database),
              ),
            ),
          ),
          const _ModuleTile(
            icon: Icons.assignment_outlined,
            title: 'ক্লিনিক্যাল বিশ্লেষণ',
            subtitle: 'পরবর্তী Phase-এ assessment workflow',
          ),
          const _ModuleTile(
            icon: Icons.receipt_long_outlined,
            title: 'প্রেসক্রিপশন',
            subtitle: 'চিকিৎসকের অনুমোদনভিত্তিক প্রেসক্রিপশন',
          ),
          const SizedBox(height: 12),
          const Text(
            'সতর্কতা: এই সংস্করণে যাচাইকৃত রোগ নির্ণয় বা ওষুধের ডোজ সরবরাহ করা হয় না।',
            style: TextStyle(color: Colors.deepOrange, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class _ModuleTile extends StatelessWidget {
  const _ModuleTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: const Color(0xFFF0F0F0),
          child: Icon(icon, color: const Color(0xFF303030)),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
