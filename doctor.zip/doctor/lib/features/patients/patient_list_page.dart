import 'package:flutter/material.dart';

import '../../core/database/database_service.dart';
import 'patient_repository.dart';

class PatientListPage extends StatefulWidget {
  const PatientListPage({super.key, required this.database});
  final DatabaseService database;

  @override
  State<PatientListPage> createState() => _PatientListPageState();
}

class _PatientListPageState extends State<PatientListPage> {
  late final PatientRepository repository;
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  List<Patient> patients = [];

  @override
  void initState() {
    super.initState();
    repository = PatientRepository(widget.database);
    _refresh();
  }

  @override
  void dispose() {
    nameController.dispose();
    phoneController.dispose();
    super.dispose();
  }

  void _refresh() => setState(() => patients = repository.getAll());

  Future<void> _addPatient() async {
    nameController.clear();
    phoneController.clear();
    final formKey = GlobalKey<FormState>();
    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('নতুন রোগী'),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'রোগীর নাম *'),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'নাম লিখুন' : null,
              ),
              const SizedBox(height: 10),
              TextField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'মোবাইল নম্বর'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('বাতিল'),
          ),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Navigator.pop(dialogContext, true);
              }
            },
            child: const Text('সংরক্ষণ'),
          ),
        ],
      ),
    );

    if (saved == true) {
      repository.create(
        fullName: nameController.text,
        phone: phoneController.text,
      );
      _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('রোগী ব্যবস্থাপনা')),
      floatingActionButton: FloatingActionButton(
        onPressed: _addPatient,
        child: const Icon(Icons.add),
      ),
      body: patients.isEmpty
          ? const Center(child: Text('এখনো কোনো রোগী যুক্ত করা হয়নি'))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: patients.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final patient = patients[index];
                return ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(patient.fullName),
                  subtitle: Text(
                    '${patient.patientCode}${patient.phone == null ? '' : ' • ${patient.phone}'}',
                  ),
                );
              },
            ),
    );
  }
}
