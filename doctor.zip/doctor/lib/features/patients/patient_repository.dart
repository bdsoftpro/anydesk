import '../../core/database/database_service.dart';

class Patient {
  const Patient({
    required this.id,
    required this.patientCode,
    required this.fullName,
    this.phone,
    this.dateOfBirth,
    this.sex,
  });

  final int id;
  final String patientCode;
  final String fullName;
  final String? phone;
  final String? dateOfBirth;
  final String? sex;
}

class PatientRepository {
  PatientRepository(this._database);

  final DatabaseService _database;

  List<Patient> getAll() {
    final rows = _database.db.select(
      'SELECT id, patient_code, full_name, phone, date_of_birth, sex '
      'FROM patients WHERE deleted_at IS NULL ORDER BY id DESC',
    );
    return rows.map((row) => Patient(
      id: row['id'] as int,
      patientCode: row['patient_code'] as String,
      fullName: row['full_name'] as String,
      phone: row['phone'] as String?,
      dateOfBirth: row['date_of_birth'] as String?,
      sex: row['sex'] as String?,
    )).toList(growable: false);
  }

  void create({
    required String fullName,
    String? phone,
    String? dateOfBirth,
    String? sex,
  }) {
    final now = DateTime.now().toUtc().toIso8601String();
    final code = 'PT-${DateTime.now().microsecondsSinceEpoch}';
    _database.db.execute(
      '''INSERT INTO patients
      (patient_code, full_name, phone, date_of_birth, sex, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)''',
      [code, fullName.trim(), _nullable(phone), _nullable(dateOfBirth),
       _nullable(sex), now, now],
    );
  }

  String? _nullable(String? value) {
    final trimmed = value?.trim();
    return trimmed == null || trimmed.isEmpty ? null : trimmed;
  }
}
