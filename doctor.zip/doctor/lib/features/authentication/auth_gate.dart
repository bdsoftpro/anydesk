import 'package:flutter/material.dart';

import '../../core/database/database_service.dart';
import 'auth_models.dart';
import 'auth_service.dart';
import '../dashboard/dashboard_page.dart';

class AuthGate extends StatefulWidget {
  const AuthGate({
    super.key,
    required this.database,
    required this.authService,
  });

  final DatabaseService database;
  final AuthService authService;

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  AuthSession? session;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _restore();
  }

  Future<void> _restore() async {
    try {
      final value = await widget.authService.restoreSession();
      if (mounted) setState(() {
        session = value;
        loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  void _onAuthenticated(AuthSession value) {
    setState(() => session = value);
  }

  Future<void> _logout() async {
    await widget.authService.logout();
    if (mounted) setState(() => session = null);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final current = session;
    if (current == null) {
      return LoginPage(
        authService: widget.authService,
        onAuthenticated: _onAuthenticated,
      );
    }
    return DashboardPage(
      database: widget.database,
      session: current,
      onLogout: _logout,
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({
    super.key,
    required this.authService,
    required this.onAuthenticated,
  });

  final AuthService authService;
  final ValueChanged<AuthSession> onAuthenticated;

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final username = TextEditingController();
  final password = TextEditingController();
  bool busy = false;
  bool registering = false;
  String? error;

  final fullName = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  final registrationNo = TextEditingController();
  final qualification = TextEditingController();
  final specialty = TextEditingController();

  @override
  void dispose() {
    username.dispose();
    password.dispose();
    fullName.dispose();
    phone.dispose();
    email.dispose();
    registrationNo.dispose();
    qualification.dispose();
    specialty.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final AuthSession result;
      if (registering) {
        result = await widget.authService.registerDoctor(
          fullName: fullName.text,
          username: username.text,
          password: password.text,
          phone: phone.text,
          email: email.text,
          registrationNo: registrationNo.text,
          qualification: qualification.text,
          specialtyName: specialty.text,
        );
      } else {
        result = await widget.authService.login(
          username: username.text,
          password: password.text,
        );
      }
      if (mounted) widget.onAuthenticated(result);
    } on AuthException catch (e) {
      if (mounted) setState(() => error = e.message);
    } catch (_) {
      if (mounted) setState(() => error = 'কাজটি সম্পন্ন হয়নি। তথ্য যাচাই করে আবার চেষ্টা করুন।');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Icon(Icons.medical_services_outlined, size: 54),
                const SizedBox(height: 12),
                Text(
                  registering ? 'ডাক্তার নিবন্ধন' : 'Doctor Login',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Doctor Prescription System',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                if (registering) ...[
                  TextField(controller: fullName, decoration: const InputDecoration(labelText: 'ডাক্তারের পূর্ণ নাম *')),
                  const SizedBox(height: 10),
                  TextField(controller: phone, decoration: const InputDecoration(labelText: 'মোবাইল')),
                  const SizedBox(height: 10),
                  TextField(controller: email, decoration: const InputDecoration(labelText: 'ইমেইল')),
                  const SizedBox(height: 10),
                  TextField(controller: registrationNo, decoration: const InputDecoration(labelText: 'Medical Registration No.')),
                  const SizedBox(height: 10),
                  TextField(controller: qualification, decoration: const InputDecoration(labelText: 'যোগ্যতা')),
                  const SizedBox(height: 10),
                  TextField(controller: specialty, decoration: const InputDecoration(labelText: 'বিশেষজ্ঞতা')),
                  const SizedBox(height: 10),
                ],
                TextField(
                  controller: username,
                  autocorrect: false,
                  decoration: const InputDecoration(labelText: 'Username'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: password,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'Password'),
                ),
                if (registering)
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text('Username ৪–৩২ অক্ষর; Password কমপক্ষে ১০ অক্ষর।',
                        style: TextStyle(fontSize: 12, color: Colors.black54)),
                  ),
                if (error != null) ...[
                  const SizedBox(height: 12),
                  Text(error!, style: const TextStyle(color: Colors.red)),
                ],
                const SizedBox(height: 18),
                FilledButton(
                  onPressed: busy ? null : _submit,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(busy ? 'অপেক্ষা করুন...' : registering ? 'নিবন্ধন করুন' : 'লগইন'),
                  ),
                ),
                TextButton(
                  onPressed: busy ? null : () => setState(() {
                    registering = !registering;
                    error = null;
                  }),
                  child: Text(registering
                      ? 'আগে থেকে অ্যাকাউন্ট আছে? লগইন করুন'
                      : 'নতুন ডাক্তার? নিবন্ধন করুন'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
