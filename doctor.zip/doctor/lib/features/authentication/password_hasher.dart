import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';

class PasswordHasher {
  static const int iterations = 210000;
  static const int saltLength = 16;
  static const int keyLength = 32;

  static Future<String> hash(String password) async {
    final random = Random.secure();
    final salt = List<int>.generate(saltLength, (_) => random.nextInt(256));
    final derived = await compute(_pbkdf2Worker, {
      'password': password,
      'salt': base64Encode(salt),
      'iterations': iterations,
      'keyLength': keyLength,
    });
    return 'pbkdf2_sha256\$$iterations\$${_hex(salt)}\$$derived';
  }

  static Future<bool> verify(String password, String encoded) async {
    final parts = encoded.split(r'$');
    if (parts.length != 4 || parts[0] != 'pbkdf2_sha256') return false;

    final rounds = int.tryParse(parts[1]);
    final salt = _decodeHex(parts[2]);
    if (rounds == null || rounds < 100000 || rounds > 1000000 || salt == null) {
      return false;
    }

    final derived = await compute(_pbkdf2Worker, {
      'password': password,
      'salt': base64Encode(salt),
      'iterations': rounds,
      'keyLength': keyLength,
    });
    return _constantTimeEquals(derived, parts[3]);
  }

  static String _pbkdf2Worker(Map<String, Object> input) =>
      _pbkdf2WorkerImpl(input);

  static String _pbkdf2WorkerImpl(Map<String, Object> input) {
    final password = utf8.encode(input['password']! as String);
    final salt = base64Decode(input['salt']! as String);
    final rounds = input['iterations']! as int;
    final length = input['keyLength']! as int;

    final hmac = Hmac(sha256, password);
    final block = Uint8List(salt.length + 4)
      ..setRange(0, salt.length, salt)
      ..[salt.length] = 0
      ..[salt.length + 1] = 0
      ..[salt.length + 2] = 0
      ..[salt.length + 3] = 1;

    var u = hmac.convert(block).bytes;
    final output = List<int>.from(u);
    for (var i = 1; i < rounds; i++) {
      u = hmac.convert(u).bytes;
      for (var j = 0; j < output.length; j++) {
        output[j] ^= u[j];
      }
    }
    return _hex(output.take(length).toList());
  }

  static String _hex(List<int> bytes) =>
      bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();

  static List<int>? _decodeHex(String value) {
    if (value.length.isOdd || !RegExp(r'^[0-9a-fA-F]+$').hasMatch(value)) {
      return null;
    }
    return List<int>.generate(
      value.length ~/ 2,
      (i) => int.parse(value.substring(i * 2, i * 2 + 2), radix: 16),
    );
  }

  static bool _constantTimeEquals(String a, String b) {
    if (a.length != b.length) return false;
    var difference = 0;
    for (var i = 0; i < a.length; i++) {
      difference |= a.codeUnitAt(i) ^ b.codeUnitAt(i);
    }
    return difference == 0;
  }
}
