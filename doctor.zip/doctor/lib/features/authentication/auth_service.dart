import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';

import '../../core/database/database_service.dart';
import '../../core/security/secure_storage_service.dart';
import 'auth_models.dart';
import 'password_hasher.dart';

class AuthService {
  AuthService({required this.database, required this.secureStorage});

  final DatabaseService database;
  final SecureStorageService secureStorage;

  Future<AuthSession> registerDoctor({
    required String fullName,
    required String username,
    required String password,
    String? phone,
    String? email,
    String? registrationNo,
    String? qualification,
    String? specialtyName,
  }) async {
    final cleanName = fullName.trim();
    final cleanUsername = username.trim().toLowerCase();

    if (cleanName.length < 2) {
      throw const AuthException('ডাক্তারের নাম সঠিকভাবে লিখুন।');
    }
    if (!RegExp(r'^[a-z0-9._-]{4,32}$').hasMatch(cleanUsername)) {
      throw const AuthException(
        'Username ৪–৩২ অক্ষরের হতে হবে; ইংরেজি ছোট হাতের অক্ষর, সংখ্যা, ., _, - ব্যবহার করুন।',
      );
    }
    if (password.length < 10) {
      throw const AuthException('Password কমপক্ষে ১০ অক্ষরের হতে হবে।');
    }

    final passwordHash = await PasswordHasher.hash(password);
    final db = database.db;
    final now = DateTime.now().toUtc().toIso8601String();

    late final int userId;
    late final int doctorId;
    db.execute('BEGIN IMMEDIATE;');
    try {
      db.execute(
        '''INSERT INTO users(username, password_hash, is_active, created_at, updated_at)
           VALUES (?, ?, 1, ?, ?)''',
        [cleanUsername, passwordHash, now, now],
      );
      userId = db.lastInsertRowId;

      int? specialtyId;
      final cleanSpecialty = specialtyName?.trim();
      if (cleanSpecialty != null && cleanSpecialty.isNotEmpty) {
        final code = 'SP-${cleanSpecialty.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]+'), '-')}';
        db.execute(
          'INSERT OR IGNORE INTO doctor_specialties(code, name_en) VALUES (?, ?)',
          [code, cleanSpecialty],
        );
        specialtyId = db.select(
          'SELECT id FROM doctor_specialties WHERE code = ?',
          [code],
        ).first['id'] as int;
      }

      final doctorCode = 'DOC-${DateTime.now().microsecondsSinceEpoch}';
      db.execute(
        '''INSERT INTO doctors
           (user_id, doctor_code, full_name, registration_no, phone, email,
            specialty_id, is_active, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)''',
        [
          userId, doctorCode, cleanName, _clean(registrationNo),
          _clean(phone), _clean(email), specialtyId, now, now,
        ],
      );
      doctorId = db.lastInsertRowId;

      if (_clean(qualification) case final String q) {
        db.execute(
          'INSERT INTO doctor_qualifications(doctor_id, qualification) VALUES (?, ?)',
          [doctorId, q],
        );
      }

      final doctorRole = db.select(
        "SELECT id FROM user_roles WHERE code = 'DOCTOR'",
      ).first['id'] as int;
      db.execute(
        '''INSERT INTO user_role_assignments
           (user_id, role_id, assigned_by, assigned_at) VALUES (?, ?, ?, ?)''',
        [userId, doctorRole, userId, now],
      );

      _audit(
        db,
        actorUserId: userId,
        action: 'DOCTOR_REGISTERED',
        entityType: 'doctors',
        entityId: '$doctorId',
        after: {'doctor_code': doctorCode, 'username': cleanUsername},
        now: now,
      );

      db.execute('COMMIT;');
    } catch (_) {
      db.execute('ROLLBACK;');
      rethrow;
    }

    return _createSession(userId, doctorId, cleanUsername, cleanName);
  }

  Future<AuthSession> login({
    required String username,
    required String password,
  }) async {
    final cleanUsername = username.trim().toLowerCase();
    final db = database.db;
    final now = DateTime.now().toUtc();
    final nowText = now.toIso8601String();

    final lockRows = db.select(
      'SELECT failed_count, locked_until FROM auth_login_attempts WHERE username_normalized = ?',
      [cleanUsername],
    );
    if (lockRows.isNotEmpty) {
      final lockedUntil = lockRows.first['locked_until'] as String?;
      if (lockedUntil != null && DateTime.tryParse(lockedUntil)?.isAfter(now) == true) {
        throw const AuthException('অনেকবার ভুল চেষ্টা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।');
      }
    }

    final rows = db.select(
      '''SELECT u.id AS user_id, u.username, u.password_hash, u.is_active,
                d.id AS doctor_id, d.full_name
         FROM users u JOIN doctors d ON d.user_id = u.id
         WHERE u.username = ? LIMIT 1''',
      [cleanUsername],
    );

    if (rows.isEmpty || rows.first['is_active'] != 1 ||
        !await PasswordHasher.verify(password, rows.first['password_hash'] as String)) {
      _recordFailedLogin(cleanUsername, now);
      throw const AuthException('Username অথবা Password সঠিক নয়।');
    }

    final row = rows.first;
    db.execute(
      'DELETE FROM auth_login_attempts WHERE username_normalized = ?',
      [cleanUsername],
    );
    final session = await _createSession(
      row['user_id'] as int,
      row['doctor_id'] as int,
      row['username'] as String,
      row['full_name'] as String,
    );
    _audit(
      db,
      actorUserId: session.userId,
      action: 'LOGIN_SUCCESS',
      entityType: 'users',
      entityId: '${session.userId}',
      after: {'username': cleanUsername},
      now: nowText,
    );
    return session;
  }

  Future<AuthSession?> restoreSession() async {
    final token = await secureStorage.readSessionToken();
    if (token == null) return null;

    final tokenHash = sha256.convert(utf8.encode(token)).toString();
    final now = DateTime.now().toUtc().toIso8601String();
    final rows = database.db.select(
      '''SELECT u.id AS user_id, u.username, d.id AS doctor_id, d.full_name
         FROM doctor_sessions s
         JOIN users u ON u.id = s.user_id
         JOIN doctors d ON d.user_id = u.id
         WHERE s.token_hash = ? AND s.revoked_at IS NULL
           AND s.expires_at > ? AND u.is_active = 1 AND d.is_active = 1
         LIMIT 1''',
      [tokenHash, now],
    );
    if (rows.isEmpty) {
      await secureStorage.clearSessionToken();
      return null;
    }
    final row = rows.first;
    return _buildSession(
      row['user_id'] as int,
      row['doctor_id'] as int,
      row['username'] as String,
      row['full_name'] as String,
    );
  }

  Future<void> logout() async {
    final token = await secureStorage.readSessionToken();
    if (token != null) {
      final tokenHash = sha256.convert(utf8.encode(token)).toString();
      final now = DateTime.now().toUtc().toIso8601String();
      final rows = database.db.select(
        'SELECT user_id FROM doctor_sessions WHERE token_hash = ? AND revoked_at IS NULL',
        [tokenHash],
      );
      database.db.execute(
        'UPDATE doctor_sessions SET revoked_at = ? WHERE token_hash = ? AND revoked_at IS NULL',
        [now, tokenHash],
      );
      if (rows.isNotEmpty) {
        _audit(
          database.db,
          actorUserId: rows.first['user_id'] as int,
          action: 'LOGOUT',
          entityType: 'doctor_sessions',
          entityId: 'revoked',
          now: now,
        );
      }
    }
    await secureStorage.clearSessionToken();
  }

  Future<bool> hasPermission(int userId, String permissionCode) async {
    final rows = database.db.select(
      '''SELECT 1
         FROM user_role_assignments ura
         JOIN role_permissions rp ON rp.role_id = ura.role_id
         JOIN permissions p ON p.id = rp.permission_id
         WHERE ura.user_id = ? AND p.code = ? LIMIT 1''',
      [userId, permissionCode],
    );
    return rows.isNotEmpty;
  }

  Future<AuthSession> _createSession(
    int userId,
    int doctorId,
    String username,
    String doctorName,
  ) async {
    final random = Random.secure();
    final token = base64UrlEncode(
      List<int>.generate(32, (_) => random.nextInt(256)),
    );
    final tokenHash = sha256.convert(utf8.encode(token)).toString();
    final now = DateTime.now().toUtc();
    final expires = now.add(const Duration(hours: 12));

    database.db.execute(
      '''INSERT INTO doctor_sessions(user_id, token_hash, expires_at, created_at)
         VALUES (?, ?, ?, ?)''',
      [userId, tokenHash, expires.toIso8601String(), now.toIso8601String()],
    );
    final sessionId = database.db.lastInsertRowId;
    try {
      await secureStorage.saveSessionToken(token);
    } catch (_) {
      database.db.execute('DELETE FROM doctor_sessions WHERE id = ?', [sessionId]);
      rethrow;
    }
    return _buildSession(userId, doctorId, username, doctorName);
  }

  AuthSession _buildSession(
    int userId, int doctorId, String username, String doctorName,
  ) {
    final roles = database.db.select(
      '''SELECT r.code FROM user_role_assignments a
         JOIN user_roles r ON r.id = a.role_id WHERE a.user_id = ?''',
      [userId],
    ).map((row) => row['code'] as String).toList();
    return AuthSession(
      userId: userId,
      doctorId: doctorId,
      username: username,
      doctorName: doctorName,
      roles: roles,
    );
  }

  void _recordFailedLogin(String username, DateTime now) {
    final db = database.db;
    final existing = db.select(
      'SELECT failed_count FROM auth_login_attempts WHERE username_normalized = ?',
      [username],
    );
    final count = (existing.isEmpty ? 0 : existing.first['failed_count'] as int) + 1;
    final lockedUntil = count >= 5
        ? now.add(const Duration(minutes: 15)).toIso8601String()
        : null;
    db.execute(
      '''INSERT INTO auth_login_attempts
         (username_normalized, failed_count, locked_until, updated_at)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(username_normalized) DO UPDATE SET
           failed_count = excluded.failed_count,
           locked_until = excluded.locked_until,
           updated_at = excluded.updated_at''',
      [username, count, lockedUntil, now.toIso8601String()],
    );
  }

  void _audit(
    dynamic db, {
    required int actorUserId,
    required String action,
    required String entityType,
    required String entityId,
    Map<String, Object?>? after,
    String? now,
  }) {
    db.execute(
      '''INSERT INTO audit_logs
         (actor_user_id, action, entity_type, entity_id, after_json, created_at)
         VALUES (?, ?, ?, ?, ?, ?)''',
      [
        actorUserId, action, entityType, entityId,
        after == null ? null : jsonEncode(after),
        now ?? DateTime.now().toUtc().toIso8601String(),
      ],
    );
  }

  String? _clean(String? value) {
    final result = value?.trim();
    return result == null || result.isEmpty ? null : result;
  }
}
