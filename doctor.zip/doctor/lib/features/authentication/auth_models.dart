class AuthSession {
  const AuthSession({
    required this.userId,
    required this.doctorId,
    required this.username,
    required this.doctorName,
    required this.roles,
  });

  final int userId;
  final int doctorId;
  final String username;
  final String doctorName;
  final List<String> roles;
}

class AuthException implements Exception {
  const AuthException(this.message);
  final String message;

  @override
  String toString() => message;
}
