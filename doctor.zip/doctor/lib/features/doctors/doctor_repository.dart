import '../../core/database/database_service.dart';

class DoctorRepository {
  DoctorRepository(this.database);
  final DatabaseService database;

  Map<String, Object?>? getProfile(int doctorId) {
    final rows = database.db.select(
      '''SELECT d.id, d.doctor_code, d.full_name, d.registration_no,
                d.phone, d.email, s.name_en AS specialty
         FROM doctors d LEFT JOIN doctor_specialties s ON s.id = d.specialty_id
         WHERE d.id = ?''',
      [doctorId],
    );
    if (rows.isEmpty) return null;
    return Map<String, Object?>.from(rows.first);
  }

  List<String> getQualifications(int doctorId) {
    return database.db.select(
      'SELECT qualification FROM doctor_qualifications WHERE doctor_id = ? ORDER BY id',
      [doctorId],
    ).map((row) => row['qualification'] as String).toList();
  }

  void updateProfile({
    required int doctorId,
    required String fullName,
    String? phone,
    String? email,
    String? registrationNo,
  }) {
    database.db.execute(
      '''UPDATE doctors SET full_name = ?, phone = ?, email = ?,
         registration_no = ?, updated_at = ? WHERE id = ?''',
      [
        fullName.trim(), _clean(phone), _clean(email), _clean(registrationNo),
        DateTime.now().toUtc().toIso8601String(), doctorId,
      ],
    );
  }

  void addQualification(int doctorId, String qualification) {
    final value = qualification.trim();
    if (value.isEmpty) return;
    database.db.execute(
      'INSERT INTO doctor_qualifications(doctor_id, qualification) VALUES (?, ?)',
      [doctorId, value],
    );
  }

  String? _clean(String? value) {
    final result = value?.trim();
    return result == null || result.isEmpty ? null : result;
  }
}
