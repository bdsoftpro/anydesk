import 'package:flutter/material.dart';

import '../../core/database/database_service.dart';
import '../authentication/auth_models.dart';
import 'doctor_repository.dart';

class DoctorProfilePage extends StatefulWidget {
  const DoctorProfilePage({
    super.key,
    required this.database,
    required this.session,
  });

  final DatabaseService database;
  final AuthSession session;

  @override
  State<DoctorProfilePage> createState() => _DoctorProfilePageState();
}

class _DoctorProfilePageState extends State<DoctorProfilePage> {
  late final DoctorRepository repository;
  final name = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  final registration = TextEditingController();
  final qualification = TextEditingController();
  Map<String, Object?>? profile;
  List<String> qualifications = [];

  @override
  void initState() {
    super.initState();
    repository = DoctorRepository(widget.database);
    _load();
  }

  void _load() {
    profile = repository.getProfile(widget.session.doctorId);
    qualifications = repository.getQualifications(widget.session.doctorId);
    name.text = profile?['full_name'] as String? ?? '';
    phone.text = profile?['phone'] as String? ?? '';
    email.text = profile?['email'] as String? ?? '';
    registration.text = profile?['registration_no'] as String? ?? '';
    setState(() {});
  }

  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    email.dispose();
    registration.dispose();
    qualification.dispose();
    super.dispose();
  }

  void _save() {
    repository.updateProfile(
      doctorId: widget.session.doctorId,
      fullName: name.text,
      phone: phone.text,
      email: email.text,
      registrationNo: registration.text,
    );
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('প্রোফাইল সংরক্ষণ হয়েছে')),
    );
    _load();
  }

  void _addQualification() {
    repository.addQualification(widget.session.doctorId, qualification.text);
    qualification.clear();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ডাক্তার প্রোফাইল')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Doctor Code: ${profile?['doctor_code'] ?? '-'}'),
          const SizedBox(height: 12),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'পূর্ণ নাম')),
          const SizedBox(height: 10),
          TextField(controller: registration, decoration: const InputDecoration(labelText: 'Registration No.')),
          const SizedBox(height: 10),
          TextField(controller: phone, decoration: const InputDecoration(labelText: 'মোবাইল')),
          const SizedBox(height: 10),
          TextField(controller: email, decoration: const InputDecoration(labelText: 'ইমেইল')),
          const SizedBox(height: 10),
          Text('বিশেষজ্ঞতা: ${profile?['specialty'] ?? 'নির্ধারিত নয়'}'),
          const SizedBox(height: 14),
          FilledButton(onPressed: _save, child: const Text('প্রোফাইল আপডেট')),
          const Divider(height: 32),
          const Text('যোগ্যতা', style: TextStyle(fontWeight: FontWeight.bold)),
          ...qualifications.map((q) => ListTile(
                dense: true,
                leading: const Icon(Icons.school_outlined),
                title: Text(q),
              )),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: qualification,
                  decoration: const InputDecoration(labelText: 'নতুন যোগ্যতা'),
                ),
              ),
              IconButton(onPressed: _addQualification, icon: const Icon(Icons.add)),
            ],
          ),
        ],
      ),
    );
  }
}
