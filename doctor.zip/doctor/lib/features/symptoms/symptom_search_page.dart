import 'package:flutter/material.dart';

import '../../core/database/database_service.dart';
import 'symptom_repository.dart';

class SymptomSearchPage extends StatefulWidget {
  const SymptomSearchPage({super.key, required this.database});
  final DatabaseService database;

  @override
  State<SymptomSearchPage> createState() => _SymptomSearchPageState();
}

class _SymptomSearchPageState extends State<SymptomSearchPage> {
  late final SymptomRepository repository;
  final controller = TextEditingController();
  List<Map<String, Object?>> results = [];

  @override
  void initState() {
    super.initState();
    repository = SymptomRepository(widget.database);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('লক্ষণ অনুসন্ধান')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: controller,
              onChanged: (value) => setState(() {
                results = repository.search(value);
              }),
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'লক্ষণ লিখুন: জ্বর / Fever',
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: results.isEmpty
                  ? const Center(
                      child: Text('অনুসন্ধানের জন্য লক্ষণ লিখুন'),
                    )
                  : ListView.builder(
                      itemCount: results.length,
                      itemBuilder: (context, index) {
                        final item = results[index];
                        return ListTile(
                          title: Text('${item['name_bn'] ?? ''}'),
                          subtitle: Text('${item['name_en'] ?? ''}'),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
