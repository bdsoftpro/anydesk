import '../../core/database/database_service.dart';

class SymptomRepository {
  SymptomRepository(this._database);
  final DatabaseService _database;

  List<Map<String, Object?>> search(String query) {
    final q = query.trim();
    if (q.isEmpty) return const [];
    final rows = _database.db.select(
      '''SELECT id, code, name_en, name_bn
         FROM symptoms
         WHERE is_active = 1
           AND (name_en LIKE ? OR name_bn LIKE ? OR code LIKE ?)
         ORDER BY name_en LIMIT 50''',
      ['%$q%', '%$q%', '%$q%'],
    );
    return rows.map((r) => Map<String, Object?>.from(r)).toList();
  }
}
