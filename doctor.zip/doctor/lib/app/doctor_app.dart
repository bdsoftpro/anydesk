import 'package:flutter/material.dart';

import '../core/database/database_service.dart';
import '../features/authentication/auth_gate.dart';
import '../features/authentication/auth_service.dart';

class DoctorApp extends StatelessWidget {
  const DoctorApp({
    super.key,
    required this.database,
    required this.authService,
  });

  final DatabaseService database;
  final AuthService authService;

  @override
  Widget build(BuildContext context) {
    const foreground = Color(0xFF2B2B2B);
    return MaterialApp(
      title: 'Doctor Prescription',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.white,
          primary: Colors.white,
          onPrimary: foreground,
          surface: Colors.white,
          onSurface: foreground,
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F7F7),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: foreground,
          elevation: 0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFFE3E3E3)),
          ),
        ),
      ),
      home: AuthGate(database: database, authService: authService),
    );
  }
}
