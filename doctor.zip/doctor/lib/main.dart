import 'package:flutter/material.dart';

import 'app/doctor_app.dart';
import 'core/database/database_service.dart';
import 'core/security/secure_storage_service.dart';
import 'features/authentication/auth_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final secureStorage = SecureStorageService();
  final database = await DatabaseService(
    secureStorage: secureStorage,
  ).initialize();

  final authService = AuthService(
    database: database,
    secureStorage: secureStorage,
  );

  runApp(DoctorApp(database: database, authService: authService));
}
