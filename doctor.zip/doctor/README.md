# Doctor Prescription System

Flutter Android starter project for a doctor-facing prescription and clinical
decision-support application.

## Technology

- Flutter + Dart
- Pure Dart domain/application services
- SQLite through `sqlite3: ^3.5.1`
- SQL migrations and FTS5 symptom search
- Hybrid clinical engine boundary (rules + optional AI adapter)
- Bengali UI labels and documentation

## Run

```bash
flutter pub get
flutter run
```

Run static checks:

```bash
flutter analyze
flutter test
```

## Project structure

```text
lib/
  app/                  App shell and theme
  core/database/        SQLite connection and migration runner
  core/errors/          Domain-safe errors
  features/
    dashboard/
    patients/
    symptoms/
    clinical_analysis/
    prescriptions/
  clinical_engine/
    rule_engine/
    ai_engine/
    orchestrator/
assets/database/migrations/
  001_core.sql
  002_patients.sql
  003_clinical.sql
  004_knowledge.sql
  005_investigations.sql
  006_medicines.sql
  007_assessments.sql
  008_prescriptions.sql
  009_followup.sql
  010_sync_security.sql
```

## Database notes

- `PRAGMA foreign_keys = ON` is enabled for every connection.
- Migrations are ordered and tracked in `schema_migrations`.
- Do not edit an already-released migration. Add a new migration instead.
- This starter opens a standard SQLite database. Before production use, integrate
  and verify the selected sqlite3mc/Multi-Cipher native build hook, key handling,
  encrypted backup/restore and WAL compatibility on every target Android ABI.
- Never store a database encryption key in source code, assets, logs or preferences
  as plaintext.
- Attachments need separately protected file storage; encrypting the SQLite file
  does not automatically encrypt exported PDFs or image files.

## Clinical safety boundary

This repository is software scaffolding, not a validated medical device or
clinical reference. No real diagnosis rules, medication doses or treatment
protocols are bundled. Clinical content must be authored/reviewed by qualified
clinicians against current, locally applicable guidelines before deployment.

AI output is advisory only. It cannot create a confirmed diagnosis, lab result,
or final prescription. A doctor must review and approve every clinical decision
and prescription. Missing information must remain explicitly missing.

## Initial scope

The app includes a working dashboard, patient registration/list, symptom catalog
search, database migrations and a safe clinical-assessment orchestration boundary.
The remaining feature folders and schema tables establish extension points for
the full ten-phase roadmap.
