import 'package:flutter_test/flutter_test.dart';
import 'package:doctor_prescription/features/authentication/password_hasher.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('password hash verifies and differs from plaintext', () async {
    const password = 'A-strong-demo-password-123';
    final encoded = await PasswordHasher.hash(password);

    expect(encoded, isNot(contains(password)));
    expect(await PasswordHasher.verify(password, encoded), isTrue);
    expect(await PasswordHasher.verify('wrong-password', encoded), isFalse);
  });
}
