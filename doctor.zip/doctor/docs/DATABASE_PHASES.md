# Database Phase Map

| Phase | Migration | Scope |
|---|---|---|
| 1 | 001_core.sql | Users, doctors, roles, permissions, settings, audit |
| 2 | 002_patients.sql | Patient profile and medical history |
| 3 | 003_clinical.sql | Symptoms, encounters, observations |
| 4 | 004_knowledge.sql | Diseases, rules, sources, differentials |
| 5 | 005_investigations.sql | Physical examination and laboratory |
| 6 | 006_medicines.sql | Medicine reference and guidelines |
| 7 | 007_assessments.sql | Clinical decision support and review |
| 8 | 008_prescriptions.sql | Doctor-reviewed prescriptions |
| 9 | 009_followup.sql | Follow-up, reports, documents |
| 10 | 010_sync_security.sql | Sync, backup, access and content versions |

All migrations are additive. Add a new numbered migration for future schema changes.
