# System Architecture

```mermaid
flowchart TD
  UI[Flutter Android UI] --> APP[Application / Domain Services]
  APP --> ORCH[Clinical Decision Orchestrator]
  ORCH --> RULE[Deterministic Rule Engine]
  ORCH --> AI[Optional AI / RAG Adapter]
  ORCH --> SAFE[Safety Validation + Doctor Review]
  APP --> REPO[Repositories / Transaction Boundary]
  REPO --> DB[(SQLite / sqlite3mc)]
  DB --> KB[Clinical Knowledge Base]
  APP --> SYNC[Optional Sync Queue]
  SYNC --> API[Remote Pure Dart API]
```

## Trust boundaries

- The Rule Engine executes only versioned, reviewed rules.
- The AI adapter receives minimized/de-identified data only.
- The orchestrator preserves conflicts and missing data.
- Doctor review is required before diagnosis confirmation or prescription finalization.
- Remote services are optional; core local workflows must continue offline.
