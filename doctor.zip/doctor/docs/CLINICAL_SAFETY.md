# Clinical Safety Requirements

1. Treat outputs as decision support, not autonomous diagnosis.
2. Never invent a test result, patient history, guideline citation or medicine fact.
3. Keep patient-reported and clinician-observed data distinct.
4. Make missing data visible.
5. Preserve Rule/AI disagreement as a conflict requiring clinician review.
6. Do not automatically populate final prescription items from AI output.
7. Require clinician-reviewed sources and versioned content for clinical rules.
8. Log who reviewed/approved a clinical assessment and prescription.
9. Minimize/de-identify data before any external AI call.
10. Validate local regulatory, privacy and professional requirements before deployment.

This project intentionally ships without active diagnosis or drug-dosing rules.
