# Phase-1 — Core Foundation & Doctor Management

## বাস্তবায়িত

- SQLite3MultipleCiphers build selection through `sqlite3` package hook.
- Per-installation database key generated with `Random.secure()` and stored through
  `flutter_secure_storage` (Android secure storage / platform keystore integration).
- Database key applied as the first SQLite statement using `PRAGMA key`.
- Database file stored in application support directory.
- Additive migration `011_phase1_auth_hardening.sql`.
- Doctor registration, login, logout and session restore.
- PBKDF2-HMAC-SHA256 password hashing (210,000 iterations, 16-byte random salt).
- 12-hour database-backed sessions; session token stored in secure storage, only token hash in DB.
- Failed-login counter and 15-minute lock after five failed attempts.
- Doctor profile and qualifications.
- Role and permission master tables, role assignment and permission lookup.
- Application settings repository.
- Audit events for doctor registration and successful login.

## Setup

```bash
flutter clean
flutter pub get
flutter run
```

The `sqlite3` v3 build hook selects SQLite3MultipleCiphers with:

```yaml
hooks:
  user_defines:
    sqlite3:
      source: sqlite3mc
```

The hook configuration is documented by the `sqlite3` package. SQLite3MC has
separate licensing terms; review those terms for your distribution.

## Important production hardening still required

- Review Android backup policy so secure storage and database backup/restore remain
  consistent. Do not restore an encrypted DB without its matching key.
- Add a controlled key-rotation and encrypted backup/restore workflow.
- Add authorization checks to every repository/service operation, not only UI visibility.
- Add account recovery, administrator provisioning and secure device revocation.
- Add clinician-approved password/session policy and operational monitoring.
- Test on the actual Android API 24+ device matrix and all target ABIs.
- Conduct security review and penetration testing before handling real patient data.

This Phase-1 starter does not claim regulatory compliance or production certification.
