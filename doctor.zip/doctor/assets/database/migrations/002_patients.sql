CREATE TABLE IF NOT EXISTS patients (
  id INTEGER PRIMARY KEY,
  patient_code TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  date_of_birth TEXT,
  sex TEXT CHECK (sex IN ('MALE','FEMALE','OTHER','UNKNOWN') OR sex IS NULL),
  blood_group TEXT,
  phone TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_patients_name ON patients(full_name);
CREATE INDEX IF NOT EXISTS idx_patients_phone ON patients(phone);
CREATE TABLE IF NOT EXISTS patient_contacts (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  contact_type TEXT NOT NULL,
  contact_value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS patient_addresses (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  address_type TEXT NOT NULL DEFAULT 'PRIMARY',
  address_text TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS patient_emergency_contacts (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  name TEXT NOT NULL,
  relationship TEXT,
  phone TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS patient_allergies (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  allergen TEXT NOT NULL,
  reaction TEXT,
  severity TEXT,
  verified_by_doctor_id INTEGER REFERENCES doctors(id),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS patient_conditions (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  condition_name TEXT NOT NULL,
  status TEXT,
  onset_date TEXT,
  notes TEXT
);
CREATE TABLE IF NOT EXISTS patient_surgeries (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  procedure_name TEXT NOT NULL,
  procedure_date TEXT,
  notes TEXT
);
CREATE TABLE IF NOT EXISTS patient_family_history (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  relation TEXT NOT NULL,
  condition_name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS patient_medications (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  medicine_name TEXT NOT NULL,
  started_at TEXT,
  ended_at TEXT,
  notes TEXT
);
CREATE TABLE IF NOT EXISTS patient_consents (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  consent_type TEXT NOT NULL,
  granted INTEGER NOT NULL CHECK (granted IN (0,1)),
  recorded_at TEXT NOT NULL
);
