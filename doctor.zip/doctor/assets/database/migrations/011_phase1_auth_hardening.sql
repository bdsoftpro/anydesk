-- Phase-1 additive migration. Existing migrations are intentionally untouched.

CREATE TABLE IF NOT EXISTS user_role_assignments (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id INTEGER NOT NULL REFERENCES user_roles(id),
  assigned_by INTEGER REFERENCES users(id),
  assigned_at TEXT NOT NULL,
  UNIQUE(user_id, role_id)
);

CREATE INDEX IF NOT EXISTS idx_user_role_assignments_user
  ON user_role_assignments(user_id);

CREATE TABLE IF NOT EXISTS auth_login_attempts (
  username_normalized TEXT PRIMARY KEY,
  failed_count INTEGER NOT NULL DEFAULT 0 CHECK(failed_count >= 0),
  locked_until TEXT,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_doctor_sessions_user_expiry
  ON doctor_sessions(user_id, expires_at, revoked_at);

CREATE INDEX IF NOT EXISTS idx_doctors_user
  ON doctors(user_id);

-- Minimal built-in roles and permissions. No default password or user is created.
INSERT OR IGNORE INTO user_roles(code, name) VALUES
  ('ADMIN', 'Administrator'),
  ('DOCTOR', 'Doctor');

INSERT OR IGNORE INTO permissions(code, name) VALUES
  ('dashboard.view', 'View dashboard'),
  ('patients.read', 'View patients'),
  ('patients.create', 'Create patients'),
  ('patients.update', 'Update patients'),
  ('clinical.read', 'View clinical records'),
  ('clinical.assess', 'Run clinical assessment'),
  ('prescriptions.read', 'View prescriptions'),
  ('prescriptions.create', 'Create prescriptions'),
  ('prescriptions.approve', 'Approve prescriptions'),
  ('doctors.manage', 'Manage doctors'),
  ('users.manage', 'Manage users'),
  ('settings.manage', 'Manage settings'),
  ('audit.read', 'View audit logs');

INSERT OR IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id
FROM user_roles r CROSS JOIN permissions p
WHERE r.code = 'ADMIN';

INSERT OR IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id
FROM user_roles r
JOIN permissions p ON p.code IN (
  'dashboard.view',
  'patients.read',
  'patients.create',
  'patients.update',
  'clinical.read',
  'clinical.assess',
  'prescriptions.read',
  'prescriptions.create'
)
WHERE r.code = 'DOCTOR';
