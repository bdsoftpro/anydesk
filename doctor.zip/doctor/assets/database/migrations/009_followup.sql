CREATE TABLE IF NOT EXISTS follow_up_schedules (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  encounter_id INTEGER REFERENCES patient_encounters(id),
  scheduled_at TEXT NOT NULL,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'PLANNED'
);
CREATE TABLE IF NOT EXISTS follow_up_records (
  id INTEGER PRIMARY KEY,
  schedule_id INTEGER REFERENCES follow_up_schedules(id),
  encounter_id INTEGER NOT NULL REFERENCES patient_encounters(id),
  outcome_notes TEXT,
  recorded_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS patient_progress_notes (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  encounter_id INTEGER REFERENCES patient_encounters(id),
  note_text TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS clinical_outcomes (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  encounter_id INTEGER REFERENCES patient_encounters(id),
  outcome_type TEXT NOT NULL,
  outcome_value TEXT,
  recorded_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS doctor_reports (
  id INTEGER PRIMARY KEY,
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  report_type TEXT NOT NULL,
  parameters_json TEXT,
  generated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS prescription_print_logs (
  id INTEGER PRIMARY KEY,
  prescription_id INTEGER NOT NULL REFERENCES prescriptions(id),
  printed_at TEXT NOT NULL,
  printed_by INTEGER REFERENCES doctors(id)
);
CREATE TABLE IF NOT EXISTS patient_document_files (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  storage_reference TEXT NOT NULL,
  mime_type TEXT,
  checksum TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS patient_attachments (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  document_file_id INTEGER NOT NULL REFERENCES patient_document_files(id),
  attachment_type TEXT,
  description TEXT
);
