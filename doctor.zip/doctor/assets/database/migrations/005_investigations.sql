CREATE TABLE IF NOT EXISTS examination_categories (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS examination_types (
  id INTEGER PRIMARY KEY,
  category_id INTEGER REFERENCES examination_categories(id),
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS examination_findings (
  id INTEGER PRIMARY KEY,
  examination_type_id INTEGER NOT NULL REFERENCES examination_types(id),
  code TEXT,
  finding_text TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS encounter_examinations (
  id INTEGER PRIMARY KEY,
  encounter_id INTEGER NOT NULL REFERENCES patient_encounters(id),
  examination_type_id INTEGER NOT NULL REFERENCES examination_types(id),
  finding_text TEXT NOT NULL,
  observed_by INTEGER REFERENCES doctors(id),
  observed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS lab_test_categories (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS lab_tests (
  id INTEGER PRIMARY KEY,
  category_id INTEGER REFERENCES lab_test_categories(id),
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  specimen TEXT,
  is_active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS disease_lab_tests (
  disease_id INTEGER NOT NULL REFERENCES diseases(id),
  lab_test_id INTEGER NOT NULL REFERENCES lab_tests(id),
  rationale TEXT,
  source_id INTEGER REFERENCES clinical_sources(id),
  PRIMARY KEY(disease_id, lab_test_id)
);
CREATE TABLE IF NOT EXISTS lab_orders (
  id INTEGER PRIMARY KEY,
  encounter_id INTEGER NOT NULL REFERENCES patient_encounters(id),
  ordered_by INTEGER NOT NULL REFERENCES doctors(id),
  status TEXT NOT NULL DEFAULT 'ORDERED',
  ordered_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS lab_order_items (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES lab_orders(id),
  lab_test_id INTEGER NOT NULL REFERENCES lab_tests(id),
  notes TEXT
);
CREATE TABLE IF NOT EXISTS lab_results (
  id INTEGER PRIMARY KEY,
  order_item_id INTEGER NOT NULL REFERENCES lab_order_items(id),
  result_source TEXT NOT NULL,
  reported_at TEXT NOT NULL,
  verified_by TEXT
);
CREATE TABLE IF NOT EXISTS lab_result_values (
  id INTEGER PRIMARY KEY,
  lab_result_id INTEGER NOT NULL REFERENCES lab_results(id),
  parameter_name TEXT NOT NULL,
  value_text TEXT,
  value_numeric REAL,
  unit TEXT,
  flag TEXT
);
CREATE TABLE IF NOT EXISTS lab_reference_ranges (
  id INTEGER PRIMARY KEY,
  lab_test_id INTEGER NOT NULL REFERENCES lab_tests(id),
  parameter_name TEXT NOT NULL,
  age_min REAL,
  age_max REAL,
  sex TEXT,
  low_value REAL,
  high_value REAL,
  unit TEXT,
  source_id INTEGER REFERENCES clinical_sources(id)
);
