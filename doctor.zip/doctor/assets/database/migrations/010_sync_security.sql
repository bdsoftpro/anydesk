CREATE TABLE IF NOT EXISTS devices (
  id INTEGER PRIMARY KEY,
  device_uuid TEXT NOT NULL UNIQUE,
  device_name TEXT,
  platform TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS device_sessions (
  id INTEGER PRIMARY KEY,
  device_id INTEGER NOT NULL REFERENCES devices(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  started_at TEXT NOT NULL,
  ended_at TEXT
);
CREATE TABLE IF NOT EXISTS sync_queue (
  id INTEGER PRIMARY KEY,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  operation TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING',
  retry_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sync_queue_status ON sync_queue(status, id);
CREATE TABLE IF NOT EXISTS sync_logs (
  id INTEGER PRIMARY KEY,
  device_id INTEGER REFERENCES devices(id),
  direction TEXT NOT NULL,
  status TEXT NOT NULL,
  details TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS backup_history (
  id INTEGER PRIMARY KEY,
  backup_reference TEXT NOT NULL,
  checksum TEXT,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS encryption_key_versions (
  id INTEGER PRIMARY KEY,
  key_version TEXT NOT NULL UNIQUE,
  key_reference TEXT NOT NULL,
  created_at TEXT NOT NULL,
  retired_at TEXT
);
CREATE TABLE IF NOT EXISTS data_access_logs (
  id INTEGER PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  patient_id INTEGER REFERENCES patients(id),
  access_type TEXT NOT NULL,
  accessed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS content_update_logs (
  id INTEGER PRIMARY KEY,
  content_type TEXT NOT NULL,
  version_label TEXT NOT NULL,
  checksum TEXT,
  reviewed_by TEXT,
  applied_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS knowledge_base_versions (
  id INTEGER PRIMARY KEY,
  version_label TEXT NOT NULL UNIQUE,
  checksum TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS system_notifications (
  id INTEGER PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  read_at TEXT,
  created_at TEXT NOT NULL
);
