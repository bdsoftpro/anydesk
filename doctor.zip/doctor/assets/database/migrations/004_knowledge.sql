CREATE TABLE IF NOT EXISTS disease_categories (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name_en TEXT NOT NULL,
  name_bn TEXT
);
CREATE TABLE IF NOT EXISTS diseases (
  id INTEGER PRIMARY KEY,
  category_id INTEGER REFERENCES disease_categories(id),
  code TEXT NOT NULL UNIQUE,
  name_en TEXT NOT NULL,
  name_bn TEXT,
  description TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1))
);
CREATE TABLE IF NOT EXISTS disease_synonyms (
  id INTEGER PRIMARY KEY,
  disease_id INTEGER NOT NULL REFERENCES diseases(id),
  language_code TEXT NOT NULL,
  synonym TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS disease_symptoms (
  disease_id INTEGER NOT NULL REFERENCES diseases(id),
  symptom_id INTEGER NOT NULL REFERENCES symptoms(id),
  relevance TEXT,
  source_id INTEGER,
  PRIMARY KEY(disease_id, symptom_id)
);
CREATE TABLE IF NOT EXISTS disease_risk_factors (
  id INTEGER PRIMARY KEY,
  disease_id INTEGER NOT NULL REFERENCES diseases(id),
  risk_factor TEXT NOT NULL,
  source_reference TEXT
);
CREATE TABLE IF NOT EXISTS disease_differentials (
  id INTEGER PRIMARY KEY,
  disease_id INTEGER NOT NULL REFERENCES diseases(id),
  differential_disease_id INTEGER NOT NULL REFERENCES diseases(id),
  rationale TEXT,
  UNIQUE(disease_id, differential_disease_id)
);
CREATE TABLE IF NOT EXISTS disease_complications (
  id INTEGER PRIMARY KEY,
  disease_id INTEGER NOT NULL REFERENCES diseases(id),
  complication TEXT NOT NULL,
  source_reference TEXT
);
CREATE TABLE IF NOT EXISTS clinical_sources (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  publisher TEXT,
  source_url TEXT,
  version_label TEXT,
  publication_date TEXT,
  reviewed_by TEXT,
  reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS clinical_rules (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  source_id INTEGER REFERENCES clinical_sources(id)
);
CREATE TABLE IF NOT EXISTS clinical_rule_conditions (
  id INTEGER PRIMARY KEY,
  rule_id INTEGER NOT NULL REFERENCES clinical_rules(id),
  field_path TEXT NOT NULL,
  operator TEXT NOT NULL,
  expected_value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS clinical_rule_actions (
  id INTEGER PRIMARY KEY,
  rule_id INTEGER NOT NULL REFERENCES clinical_rules(id),
  action_type TEXT NOT NULL,
  payload_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS clinical_rule_versions (
  id INTEGER PRIMARY KEY,
  rule_id INTEGER NOT NULL REFERENCES clinical_rules(id),
  version_no INTEGER NOT NULL,
  content_hash TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT,
  UNIQUE(rule_id, version_no)
);
