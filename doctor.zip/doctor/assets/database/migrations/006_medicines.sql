CREATE TABLE IF NOT EXISTS medicine_categories (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS medicine_generics (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  generic_name TEXT NOT NULL,
  description TEXT
);
CREATE TABLE IF NOT EXISTS medicine_manufacturers (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS medicine_brands (
  id INTEGER PRIMARY KEY,
  generic_id INTEGER NOT NULL REFERENCES medicine_generics(id),
  manufacturer_id INTEGER REFERENCES medicine_manufacturers(id),
  brand_name TEXT NOT NULL,
  strength TEXT,
  dosage_form TEXT,
  is_active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS medicine_dosage_forms (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS medicine_strengths (
  id INTEGER PRIMARY KEY,
  value TEXT NOT NULL,
  unit TEXT NOT NULL,
  UNIQUE(value, unit)
);
CREATE TABLE IF NOT EXISTS medicine_routes (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS medicine_packages (
  id INTEGER PRIMARY KEY,
  brand_id INTEGER NOT NULL REFERENCES medicine_brands(id),
  package_description TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS medicine_safety_rules (
  id INTEGER PRIMARY KEY,
  generic_id INTEGER NOT NULL REFERENCES medicine_generics(id),
  rule_type TEXT NOT NULL,
  description TEXT NOT NULL,
  source_id INTEGER REFERENCES clinical_sources(id),
  reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS medicine_interactions (
  id INTEGER PRIMARY KEY,
  generic_id_a INTEGER NOT NULL REFERENCES medicine_generics(id),
  generic_id_b INTEGER NOT NULL REFERENCES medicine_generics(id),
  severity TEXT,
  description TEXT NOT NULL,
  source_id INTEGER REFERENCES clinical_sources(id),
  CHECK(generic_id_a < generic_id_b),
  UNIQUE(generic_id_a, generic_id_b)
);
CREATE TABLE IF NOT EXISTS treatment_guidelines (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  source_id INTEGER REFERENCES clinical_sources(id),
  version_label TEXT,
  status TEXT NOT NULL DEFAULT 'DRAFT'
);
CREATE TABLE IF NOT EXISTS disease_treatment_guidelines (
  disease_id INTEGER NOT NULL REFERENCES diseases(id),
  guideline_id INTEGER NOT NULL REFERENCES treatment_guidelines(id),
  PRIMARY KEY(disease_id, guideline_id)
);
CREATE TABLE IF NOT EXISTS guideline_versions (
  id INTEGER PRIMARY KEY,
  guideline_id INTEGER NOT NULL REFERENCES treatment_guidelines(id),
  version_no INTEGER NOT NULL,
  content_hash TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT,
  UNIQUE(guideline_id, version_no)
);
