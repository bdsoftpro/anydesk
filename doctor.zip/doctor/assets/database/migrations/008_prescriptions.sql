CREATE TABLE IF NOT EXISTS prescriptions (
  id INTEGER PRIMARY KEY,
  encounter_id INTEGER NOT NULL REFERENCES patient_encounters(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  prescription_no TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'DRAFT'
    CHECK(status IN ('DRAFT','UNDER_REVIEW','APPROVED','SIGNED','CANCELLED')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS prescription_diagnoses (
  id INTEGER PRIMARY KEY,
  prescription_id INTEGER NOT NULL REFERENCES prescriptions(id),
  disease_id INTEGER NOT NULL REFERENCES diseases(id),
  doctor_confirmed INTEGER NOT NULL DEFAULT 0 CHECK(doctor_confirmed IN (0,1))
);
CREATE TABLE IF NOT EXISTS prescription_items (
  id INTEGER PRIMARY KEY,
  prescription_id INTEGER NOT NULL REFERENCES prescriptions(id),
  brand_id INTEGER REFERENCES medicine_brands(id),
  medicine_text TEXT NOT NULL,
  dose_text TEXT,
  route_id INTEGER REFERENCES medicine_routes(id),
  frequency_text TEXT,
  duration_text TEXT,
  quantity_text TEXT,
  instructions TEXT,
  doctor_approved INTEGER NOT NULL DEFAULT 0 CHECK(doctor_approved IN (0,1))
);
CREATE TABLE IF NOT EXISTS prescription_instructions (
  id INTEGER PRIMARY KEY,
  prescription_id INTEGER NOT NULL REFERENCES prescriptions(id),
  instruction_text TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS prescription_investigations (
  id INTEGER PRIMARY KEY,
  prescription_id INTEGER NOT NULL REFERENCES prescriptions(id),
  lab_test_id INTEGER NOT NULL REFERENCES lab_tests(id),
  instructions TEXT
);
CREATE TABLE IF NOT EXISTS prescription_notes (
  id INTEGER PRIMARY KEY,
  prescription_id INTEGER NOT NULL REFERENCES prescriptions(id),
  note_text TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS prescription_versions (
  id INTEGER PRIMARY KEY,
  prescription_id INTEGER NOT NULL REFERENCES prescriptions(id),
  version_no INTEGER NOT NULL,
  snapshot_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(prescription_id, version_no)
);
CREATE TABLE IF NOT EXISTS prescription_signatures (
  id INTEGER PRIMARY KEY,
  prescription_id INTEGER NOT NULL REFERENCES prescriptions(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  signature_reference TEXT,
  signed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS prescription_templates (
  id INTEGER PRIMARY KEY,
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  template_name TEXT NOT NULL,
  template_json TEXT NOT NULL
);
