CREATE TABLE IF NOT EXISTS symptom_categories (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name_en TEXT NOT NULL,
  name_bn TEXT
);
CREATE TABLE IF NOT EXISTS symptoms (
  id INTEGER PRIMARY KEY,
  category_id INTEGER REFERENCES symptom_categories(id),
  code TEXT NOT NULL UNIQUE,
  name_en TEXT NOT NULL,
  name_bn TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1))
);
CREATE TABLE IF NOT EXISTS symptom_synonyms (
  id INTEGER PRIMARY KEY,
  symptom_id INTEGER NOT NULL REFERENCES symptoms(id),
  language_code TEXT NOT NULL,
  synonym TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_symptom_synonyms_text ON symptom_synonyms(synonym);
CREATE TABLE IF NOT EXISTS symptom_questions (
  id INTEGER PRIMARY KEY,
  symptom_id INTEGER NOT NULL REFERENCES symptoms(id),
  question_text TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS symptom_question_options (
  id INTEGER PRIMARY KEY,
  question_id INTEGER NOT NULL REFERENCES symptom_questions(id),
  option_text TEXT NOT NULL,
  code TEXT
);
CREATE TABLE IF NOT EXISTS patient_encounters (
  id INTEGER PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES patients(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  encounter_at TEXT NOT NULL,
  chief_complaint TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'OPEN',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_encounters_patient_date ON patient_encounters(patient_id, encounter_at);
CREATE TABLE IF NOT EXISTS encounter_symptoms (
  id INTEGER PRIMARY KEY,
  encounter_id INTEGER NOT NULL REFERENCES patient_encounters(id),
  symptom_id INTEGER NOT NULL REFERENCES symptoms(id),
  source_type TEXT NOT NULL CHECK (source_type IN ('PATIENT_REPORTED','CLINICIAN_OBSERVED')),
  onset TEXT,
  duration TEXT,
  severity TEXT,
  frequency TEXT,
  location TEXT,
  progression TEXT,
  notes TEXT
);
CREATE TABLE IF NOT EXISTS observation_types (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name_en TEXT NOT NULL,
  name_bn TEXT,
  unit TEXT
);
CREATE TABLE IF NOT EXISTS observation_methods (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS clinical_observations (
  id INTEGER PRIMARY KEY,
  encounter_id INTEGER NOT NULL REFERENCES patient_encounters(id),
  observation_type_id INTEGER NOT NULL REFERENCES observation_types(id),
  value_numeric REAL,
  value_text TEXT,
  unit TEXT,
  method_id INTEGER REFERENCES observation_methods(id),
  observed_at TEXT NOT NULL,
  recorded_by INTEGER REFERENCES doctors(id)
);
