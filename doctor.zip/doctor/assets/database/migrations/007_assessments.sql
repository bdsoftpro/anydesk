CREATE TABLE IF NOT EXISTS clinical_assessments (
  id INTEGER PRIMARY KEY,
  encounter_id INTEGER NOT NULL REFERENCES patient_encounters(id),
  status TEXT NOT NULL DEFAULT 'PENDING_REVIEW',
  input_snapshot_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS assessment_inputs (
  id INTEGER PRIMARY KEY,
  assessment_id INTEGER NOT NULL REFERENCES clinical_assessments(id),
  input_key TEXT NOT NULL,
  input_value TEXT
);
CREATE TABLE IF NOT EXISTS assessment_differentials (
  id INTEGER PRIMARY KEY,
  assessment_id INTEGER NOT NULL REFERENCES clinical_assessments(id),
  disease_id INTEGER NOT NULL REFERENCES diseases(id),
  rank_order INTEGER,
  rationale TEXT,
  confidence_label TEXT
);
CREATE TABLE IF NOT EXISTS assessment_evidence (
  id INTEGER PRIMARY KEY,
  assessment_id INTEGER NOT NULL REFERENCES clinical_assessments(id),
  evidence_type TEXT NOT NULL,
  evidence_text TEXT NOT NULL,
  source_id INTEGER REFERENCES clinical_sources(id)
);
CREATE TABLE IF NOT EXISTS assessment_missing_data (
  id INTEGER PRIMARY KEY,
  assessment_id INTEGER NOT NULL REFERENCES clinical_assessments(id),
  missing_item TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS assessment_alerts (
  id INTEGER PRIMARY KEY,
  assessment_id INTEGER NOT NULL REFERENCES clinical_assessments(id),
  severity TEXT NOT NULL,
  alert_text TEXT NOT NULL,
  acknowledged_at TEXT
);
CREATE TABLE IF NOT EXISTS assessment_investigations (
  id INTEGER PRIMARY KEY,
  assessment_id INTEGER NOT NULL REFERENCES clinical_assessments(id),
  lab_test_id INTEGER NOT NULL REFERENCES lab_tests(id),
  rationale TEXT
);
CREATE TABLE IF NOT EXISTS assessment_guidelines (
  id INTEGER PRIMARY KEY,
  assessment_id INTEGER NOT NULL REFERENCES clinical_assessments(id),
  guideline_id INTEGER NOT NULL REFERENCES treatment_guidelines(id)
);
CREATE TABLE IF NOT EXISTS ai_analysis_runs (
  id INTEGER PRIMARY KEY,
  assessment_id INTEGER NOT NULL REFERENCES clinical_assessments(id),
  provider TEXT,
  model_identifier TEXT,
  prompt_version TEXT,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS ai_source_references (
  id INTEGER PRIMARY KEY,
  ai_run_id INTEGER NOT NULL REFERENCES ai_analysis_runs(id),
  source_id INTEGER REFERENCES clinical_sources(id),
  citation_text TEXT
);
CREATE TABLE IF NOT EXISTS clinical_engine_versions (
  id INTEGER PRIMARY KEY,
  engine_name TEXT NOT NULL,
  version_label TEXT NOT NULL,
  content_hash TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(engine_name, version_label)
);
CREATE TABLE IF NOT EXISTS clinical_review_decisions (
  id INTEGER PRIMARY KEY,
  assessment_id INTEGER NOT NULL REFERENCES clinical_assessments(id),
  doctor_id INTEGER NOT NULL REFERENCES doctors(id),
  decision TEXT NOT NULL,
  notes TEXT,
  reviewed_at TEXT NOT NULL
);
